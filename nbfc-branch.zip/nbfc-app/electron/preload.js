const { contextBridge, ipcRenderer } = require("electron");

// Expose a safe, typed API to the React app
// No direct Node.js access from the renderer
contextBridge.exposeInMainWorld("api", {
  // Config
  getConfig: () => ipcRenderer.invoke("get-config"),
  saveConfig: (config) => ipcRenderer.invoke("save-config", config),
  resetConfig: () => ipcRenderer.invoke("reset-config"),

  // Settings
  getSettings: () => ipcRenderer.invoke("get-settings"),
  saveSettings: (settings) => ipcRenderer.invoke("save-settings", settings),

  // File operations
  pickExcelFile: () => ipcRenderer.invoke("pick-excel-file"),
  previewExcel: (filePath) => ipcRenderer.invoke("preview-excel", filePath),
  importExcel: (opts) => ipcRenderer.invoke("import-excel", opts),

  // Data
  getImports: () => ipcRenderer.invoke("get-imports"),
  deleteImport: (id) => ipcRenderer.invoke("delete-import", id),
  getBranchData: (filters) => ipcRenderer.invoke("get-branch-data", filters),
  getDashboardSummary: (importId) => ipcRenderer.invoke("get-dashboard-summary", importId),
  getFilterOptions: (importId) => ipcRenderer.invoke("get-filter-options", importId),

  // Targets
  saveTarget: (target) => ipcRenderer.invoke("save-target", target),
  getTargets: (filters) => ipcRenderer.invoke("get-targets", filters),
  deleteTarget: (id) => ipcRenderer.invoke("delete-target", id),

  // Reports
  generateReport: (opts) => ipcRenderer.invoke("generate-report", opts),
  openFile: (filePath) => ipcRenderer.invoke("open-file", filePath),
  openReportsFolder: () => ipcRenderer.invoke("open-reports-folder"),

  // App
  getAppInfo: () => ipcRenderer.invoke("get-app-info"),
  backupDb: () => ipcRenderer.invoke("backup-db"),
});
