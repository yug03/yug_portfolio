const { app, BrowserWindow, ipcMain, dialog, shell } = require("electron");
const path = require("path");
const fs = require("fs");

// ─── Determine if dev or prod ───────────────────────────────────────────────
const isDev = process.env.NODE_ENV === "development";

// ─── App data directory (local, never leaves machine) ───────────────────────
const USER_DATA = app.getPath("userData");
const DB_PATH = path.join(USER_DATA, "nbfc_intelligence.db");
const CONFIG_PATH = path.join(USER_DATA, "column_config.json");
const REPORTS_DIR = path.join(USER_DATA, "reports");
const BACKUPS_DIR = path.join(USER_DATA, "backups");

// Ensure directories exist
[REPORTS_DIR, BACKUPS_DIR].forEach((dir) => {
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
});

// ─── Database setup ──────────────────────────────────────────────────────────
let db;
function initDB() {
  const Database = require("better-sqlite3");
  db = new Database(DB_PATH);
  db.pragma("journal_mode = WAL");
  db.pragma("foreign_keys = ON");

  db.exec(`
    CREATE TABLE IF NOT EXISTS imports (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      filename TEXT NOT NULL,
      import_date TEXT NOT NULL,
      record_count INTEGER,
      period TEXT,
      notes TEXT
    );

    CREATE TABLE IF NOT EXISTS branch_data (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      import_id INTEGER REFERENCES imports(id) ON DELETE CASCADE,
      branch_code TEXT,
      branch_name TEXT,
      state TEXT,
      region TEXT,
      employee_name TEXT,
      employee_id TEXT,
      date TEXT,
      period_type TEXT DEFAULT 'monthly',
      -- Disbursement
      disbursement_target REAL DEFAULT 0,
      disbursement_actual REAL DEFAULT 0,
      -- KYC
      kyc_target REAL DEFAULT 0,
      kyc_actual REAL DEFAULT 0,
      -- Collections
      collection_target REAL DEFAULT 0,
      collection_actual REAL DEFAULT 0,
      -- PAR
      par30 REAL DEFAULT 0,
      par60 REAL DEFAULT 0,
      par90 REAL DEFAULT 0,
      portfolio_outstanding REAL DEFAULT 0,
      -- Customers
      active_loans INTEGER DEFAULT 0,
      new_customers INTEGER DEFAULT 0,
      -- Extra fields (flexible JSON)
      extra_data TEXT DEFAULT '{}',
      -- Calculated (stored for performance)
      disbursement_pct REAL DEFAULT 0,
      kyc_pct REAL DEFAULT 0,
      collection_efficiency REAL DEFAULT 0,
      conversion_ratio REAL DEFAULT 0,
      par90_pct REAL DEFAULT 0,
      run_rate REAL DEFAULT 0,
      performance_flag TEXT DEFAULT 'normal'
    );

    CREATE TABLE IF NOT EXISTS targets (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      branch_code TEXT,
      branch_name TEXT,
      state TEXT,
      region TEXT,
      target_type TEXT DEFAULT 'monthly',
      period TEXT,
      disbursement_target REAL DEFAULT 0,
      kyc_target REAL DEFAULT 0,
      collection_target REAL DEFAULT 0,
      created_at TEXT DEFAULT (datetime('now')),
      notes TEXT
    );

    CREATE TABLE IF NOT EXISTS app_settings (
      key TEXT PRIMARY KEY,
      value TEXT
    );

    INSERT OR IGNORE INTO app_settings (key, value) VALUES
      ('working_days_per_month', '25'),
      ('par90_threshold', '5'),
      ('underperform_threshold', '70'),
      ('org_name', 'NBFC Branch Intelligence'),
      ('currency_symbol', '₹'),
      ('disbursement_unit', 'Lakhs');
  `);
}

// ─── Default column config ───────────────────────────────────────────────────
const DEFAULT_CONFIG = {
  version: "1.0",
  description: "Map your Excel column names to system fields. Edit column names to match your Excel file.",
  mappings: {
    branch_code: { label: "Branch Code", excelColumn: "Branch Code", required: true },
    branch_name: { label: "Branch Name", excelColumn: "Branch Name", required: true },
    state: { label: "State", excelColumn: "State", required: false },
    region: { label: "Region", excelColumn: "Region", required: false },
    employee_name: { label: "Employee Name", excelColumn: "Employee Name", required: false },
    employee_id: { label: "Employee ID", excelColumn: "Employee ID", required: false },
    date: { label: "Date", excelColumn: "Date", required: false },
    disbursement_target: { label: "Disbursement Target", excelColumn: "Disbursement Target", required: false, type: "number" },
    disbursement_actual: { label: "Disbursement Actual", excelColumn: "Disbursement Actual", required: false, type: "number" },
    kyc_target: { label: "KYC Target", excelColumn: "KYC Target", required: false, type: "number" },
    kyc_actual: { label: "KYC Actual", excelColumn: "KYC Actual", required: false, type: "number" },
    collection_target: { label: "Collection Target", excelColumn: "Collection Target", required: false, type: "number" },
    collection_actual: { label: "Collection Actual", excelColumn: "Collection Actual", required: false, type: "number" },
    par30: { label: "PAR 30", excelColumn: "PAR 30", required: false, type: "number" },
    par60: { label: "PAR 60", excelColumn: "PAR 60", required: false, type: "number" },
    par90: { label: "PAR 90", excelColumn: "PAR 90", required: false, type: "number" },
    portfolio_outstanding: { label: "Portfolio Outstanding", excelColumn: "Portfolio Outstanding", required: false, type: "number" },
    active_loans: { label: "Active Loans", excelColumn: "Active Loans", required: false, type: "number" },
    new_customers: { label: "New Customers", excelColumn: "New Customers", required: false, type: "number" }
  },
  kpi_settings: {
    underperform_threshold: 70,
    par90_alert_threshold: 5,
    working_days_per_month: 25,
    days_elapsed: 15
  }
};

function getConfig() {
  if (!fs.existsSync(CONFIG_PATH)) {
    fs.writeFileSync(CONFIG_PATH, JSON.stringify(DEFAULT_CONFIG, null, 2));
  }
  try {
    return JSON.parse(fs.readFileSync(CONFIG_PATH, "utf8"));
  } catch {
    return DEFAULT_CONFIG;
  }
}

// ─── KPI Calculations ────────────────────────────────────────────────────────
function calculateKPIs(row, settings) {
  const workingDays = parseInt(settings.working_days_per_month || 25);
  const daysElapsed = parseInt(settings.days_elapsed || 15);

  const disbPct = row.disbursement_target > 0
    ? (row.disbursement_actual / row.disbursement_target) * 100 : 0;

  const kycPct = row.kyc_target > 0
    ? (row.kyc_actual / row.kyc_target) * 100 : 0;

  const collEff = row.collection_target > 0
    ? (row.collection_actual / row.collection_target) * 100 : 0;

  const convRatio = row.kyc_actual > 0
    ? (row.disbursement_actual / row.kyc_actual) * 100 : 0;

  const par90Pct = row.portfolio_outstanding > 0
    ? (row.par90 / row.portfolio_outstanding) * 100 : 0;

  // Run rate: project actual to month end based on days elapsed
  const runRate = daysElapsed > 0
    ? (row.disbursement_actual / daysElapsed) * workingDays : 0;

  const threshold = parseInt(settings.underperform_threshold || 70);
  const par90Threshold = parseFloat(settings.par90_alert_threshold || 5);

  let flag = "normal";
  if (disbPct < threshold || kycPct < threshold) flag = "underperform";
  if (par90Pct > par90Threshold) flag = "par_alert";
  if (disbPct < 40 || kycPct < 40) flag = "critical";
  if (disbPct >= 100 && kycPct >= 90) flag = "star";

  return {
    disbursement_pct: Math.round(disbPct * 10) / 10,
    kyc_pct: Math.round(kycPct * 10) / 10,
    collection_efficiency: Math.round(collEff * 10) / 10,
    conversion_ratio: Math.round(convRatio * 10) / 10,
    par90_pct: Math.round(par90Pct * 10) / 10,
    run_rate: Math.round(runRate * 10) / 10,
    performance_flag: flag,
  };
}

// ─── Window ──────────────────────────────────────────────────────────────────
let mainWindow;

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1400,
    height: 900,
    minWidth: 1100,
    minHeight: 700,
    webPreferences: {
      preload: path.join(__dirname, "preload.js"),
      contextIsolation: true,
      nodeIntegration: false,
    },
    titleBarStyle: "hidden",
    titleBarOverlay: {
      color: "#07090f",
      symbolColor: "#8b95a9",
      height: 40,
    },
    backgroundColor: "#07090f",
    show: false,
    icon: path.join(__dirname, "../public/icon.ico"),
  });

  if (isDev) {
    mainWindow.loadURL("http://localhost:5173");
    mainWindow.webContents.openDevTools();
  } else {
    mainWindow.loadFile(path.join(__dirname, "../dist/index.html"));
  }

  mainWindow.once("ready-to-show", () => mainWindow.show());
}

app.whenReady().then(() => {
  initDB();
  createWindow();
  app.on("activate", () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on("window-all-closed", () => {
  if (process.platform !== "darwin") app.quit();
});

// ─── IPC Handlers ────────────────────────────────────────────────────────────

// Config
ipcMain.handle("get-config", () => getConfig());

ipcMain.handle("save-config", (_, config) => {
  fs.writeFileSync(CONFIG_PATH, JSON.stringify(config, null, 2));
  return { success: true };
});

ipcMain.handle("reset-config", () => {
  fs.writeFileSync(CONFIG_PATH, JSON.stringify(DEFAULT_CONFIG, null, 2));
  return DEFAULT_CONFIG;
});

// Settings
ipcMain.handle("get-settings", () => {
  const rows = db.prepare("SELECT key, value FROM app_settings").all();
  return Object.fromEntries(rows.map((r) => [r.key, r.value]));
});

ipcMain.handle("save-settings", (_, settings) => {
  const upsert = db.prepare(
    "INSERT OR REPLACE INTO app_settings (key, value) VALUES (?, ?)"
  );
  const saveAll = db.transaction((s) => {
    Object.entries(s).forEach(([k, v]) => upsert.run(k, String(v)));
  });
  saveAll(settings);
  return { success: true };
});

// File picker
ipcMain.handle("pick-excel-file", async () => {
  const result = await dialog.showOpenDialog(mainWindow, {
    title: "Select Branch Performance Excel File",
    filters: [{ name: "Excel Files", extensions: ["xlsx", "xls", "csv"] }],
    properties: ["openFile"],
  });
  if (result.canceled) return null;
  return result.filePaths[0];
});

// Preview Excel columns
ipcMain.handle("preview-excel", async (_, filePath) => {
  const XLSX = require("xlsx");
  const wb = XLSX.readFile(filePath);
  const ws = wb.Sheets[wb.SheetNames[0]];
  const data = XLSX.utils.sheet_to_json(ws, { header: 1 });
  const headers = data[0] || [];
  const preview = data.slice(1, 6).map((row) => {
    const obj = {};
    headers.forEach((h, i) => (obj[h] = row[i] ?? ""));
    return obj;
  });
  return { headers, preview, sheetName: wb.SheetNames[0], totalRows: data.length - 1 };
});

// Import Excel data
ipcMain.handle("import-excel", async (_, { filePath, period, periodType, notes, daysElapsed }) => {
  const XLSX = require("xlsx");
  const config = getConfig();
  const settings = Object.fromEntries(
    db.prepare("SELECT key, value FROM app_settings").all().map((r) => [r.key, r.value])
  );
  settings.days_elapsed = daysElapsed || settings.working_days_per_month;

  const wb = XLSX.readFile(filePath);
  const ws = wb.Sheets[wb.SheetNames[0]];
  const rows = XLSX.utils.sheet_to_json(ws);

  if (!rows.length) return { success: false, error: "No data found in file" };

  const importStmt = db.prepare(
    "INSERT INTO imports (filename, import_date, record_count, period, notes) VALUES (?, datetime('now'), ?, ?, ?)"
  );
  const importResult = importStmt.run(
    path.basename(filePath), rows.length, period || "", notes || ""
  );
  const importId = importResult.lastInsertRowid;

  const insertRow = db.prepare(`
    INSERT INTO branch_data (
      import_id, branch_code, branch_name, state, region,
      employee_name, employee_id, date, period_type,
      disbursement_target, disbursement_actual,
      kyc_target, kyc_actual,
      collection_target, collection_actual,
      par30, par60, par90, portfolio_outstanding,
      active_loans, new_customers, extra_data,
      disbursement_pct, kyc_pct, collection_efficiency,
      conversion_ratio, par90_pct, run_rate, performance_flag
    ) VALUES (
      ?, ?, ?, ?, ?, ?, ?, ?, ?,
      ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,
      ?, ?, ?, ?, ?, ?, ?, ?, ?, ?
    )
  `);

  const insertAll = db.transaction((rows) => {
    const m = config.mappings;
    rows.forEach((row) => {
      const getVal = (field) => row[m[field]?.excelColumn] ?? row[field] ?? 0;
      const getStr = (field) => String(row[m[field]?.excelColumn] ?? row[field] ?? "");

      // Collect extra columns not in mapping
      const mappedCols = new Set(Object.values(m).map((v) => v.excelColumn));
      const extra = {};
      Object.keys(row).forEach((k) => {
        if (!mappedCols.has(k)) extra[k] = row[k];
      });

      const r = {
        branch_code: getStr("branch_code"),
        branch_name: getStr("branch_name"),
        state: getStr("state"),
        region: getStr("region"),
        employee_name: getStr("employee_name"),
        employee_id: getStr("employee_id"),
        date: getStr("date"),
        period_type: periodType || "monthly",
        disbursement_target: parseFloat(getVal("disbursement_target")) || 0,
        disbursement_actual: parseFloat(getVal("disbursement_actual")) || 0,
        kyc_target: parseFloat(getVal("kyc_target")) || 0,
        kyc_actual: parseFloat(getVal("kyc_actual")) || 0,
        collection_target: parseFloat(getVal("collection_target")) || 0,
        collection_actual: parseFloat(getVal("collection_actual")) || 0,
        par30: parseFloat(getVal("par30")) || 0,
        par60: parseFloat(getVal("par60")) || 0,
        par90: parseFloat(getVal("par90")) || 0,
        portfolio_outstanding: parseFloat(getVal("portfolio_outstanding")) || 0,
        active_loans: parseInt(getVal("active_loans")) || 0,
        new_customers: parseInt(getVal("new_customers")) || 0,
      };

      const kpis = calculateKPIs(r, settings);
      insertRow.run(
        importId, r.branch_code, r.branch_name, r.state, r.region,
        r.employee_name, r.employee_id, r.date, r.period_type,
        r.disbursement_target, r.disbursement_actual,
        r.kyc_target, r.kyc_actual,
        r.collection_target, r.collection_actual,
        r.par30, r.par60, r.par90, r.portfolio_outstanding,
        r.active_loans, r.new_customers, JSON.stringify(extra),
        kpis.disbursement_pct, kpis.kyc_pct, kpis.collection_efficiency,
        kpis.conversion_ratio, kpis.par90_pct, kpis.run_rate, kpis.performance_flag
      );
    });
  });

  insertAll(rows);
  return { success: true, importId, recordCount: rows.length };
});

// Get all imports
ipcMain.handle("get-imports", () => {
  return db.prepare("SELECT * FROM imports ORDER BY import_date DESC").all();
});

// Delete import
ipcMain.handle("delete-import", (_, importId) => {
  db.prepare("DELETE FROM imports WHERE id = ?").run(importId);
  return { success: true };
});

// Get branch data with filters
ipcMain.handle("get-branch-data", (_, filters = {}) => {
  let query = "SELECT * FROM branch_data WHERE 1=1";
  const params = [];

  if (filters.importId) { query += " AND import_id = ?"; params.push(filters.importId); }
  if (filters.state) { query += " AND state = ?"; params.push(filters.state); }
  if (filters.region) { query += " AND region = ?"; params.push(filters.region); }
  if (filters.flag) { query += " AND performance_flag = ?"; params.push(filters.flag); }
  if (filters.search) {
    query += " AND (branch_name LIKE ? OR branch_code LIKE ? OR employee_name LIKE ?)";
    const s = `%${filters.search}%`;
    params.push(s, s, s);
  }
  if (filters.minDisb !== undefined) {
    query += " AND disbursement_pct >= ?"; params.push(filters.minDisb);
  }
  if (filters.maxDisb !== undefined) {
    query += " AND disbursement_pct <= ?"; params.push(filters.maxDisb);
  }

  query += " ORDER BY disbursement_pct ASC";
  return db.prepare(query).all(...params);
});

// Dashboard summary
ipcMain.handle("get-dashboard-summary", (_, importId) => {
  const whereClause = importId ? "WHERE import_id = ?" : "";
  const params = importId ? [importId] : [];

  const summary = db.prepare(`
    SELECT
      COUNT(*) as total_branches,
      SUM(disbursement_actual) as total_disbursement,
      SUM(disbursement_target) as total_target,
      AVG(disbursement_pct) as avg_disbursement_pct,
      AVG(kyc_pct) as avg_kyc_pct,
      AVG(collection_efficiency) as avg_collection,
      AVG(par90_pct) as avg_par90,
      SUM(new_customers) as total_new_customers,
      SUM(CASE WHEN performance_flag = 'critical' THEN 1 ELSE 0 END) as critical_count,
      SUM(CASE WHEN performance_flag = 'underperform' THEN 1 ELSE 0 END) as underperform_count,
      SUM(CASE WHEN performance_flag = 'par_alert' THEN 1 ELSE 0 END) as par_alert_count,
      SUM(CASE WHEN performance_flag = 'star' THEN 1 ELSE 0 END) as star_count,
      SUM(CASE WHEN performance_flag = 'normal' THEN 1 ELSE 0 END) as normal_count
    FROM branch_data ${whereClause}
  `).get(...params);

  const stateBreakdown = db.prepare(`
    SELECT state,
      COUNT(*) as branches,
      AVG(disbursement_pct) as avg_disb,
      SUM(disbursement_actual) as total_disb
    FROM branch_data ${whereClause}
    GROUP BY state ORDER BY avg_disb DESC
  `).all(...params);

  const flagDistribution = db.prepare(`
    SELECT performance_flag, COUNT(*) as count
    FROM branch_data ${whereClause}
    GROUP BY performance_flag
  `).all(...params);

  return { summary, stateBreakdown, flagDistribution };
});

// Get distinct filter values
ipcMain.handle("get-filter-options", (_, importId) => {
  const w = importId ? "WHERE import_id = ?" : "";
  const p = importId ? [importId] : [];
  const states = db.prepare(`SELECT DISTINCT state FROM branch_data ${w} ORDER BY state`).all(...p);
  const regions = db.prepare(`SELECT DISTINCT region FROM branch_data ${w} ORDER BY region`).all(...p);
  return {
    states: states.map((r) => r.state).filter(Boolean),
    regions: regions.map((r) => r.region).filter(Boolean),
  };
});

// Targets
ipcMain.handle("save-target", (_, target) => {
  const stmt = db.prepare(`
    INSERT OR REPLACE INTO targets
    (branch_code, branch_name, state, region, target_type, period,
     disbursement_target, kyc_target, collection_target, notes)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);
  stmt.run(
    target.branch_code, target.branch_name, target.state, target.region,
    target.target_type, target.period,
    target.disbursement_target, target.kyc_target, target.collection_target, target.notes
  );
  return { success: true };
});

ipcMain.handle("get-targets", (_, filters = {}) => {
  let q = "SELECT * FROM targets WHERE 1=1";
  const p = [];
  if (filters.target_type) { q += " AND target_type = ?"; p.push(filters.target_type); }
  if (filters.state) { q += " AND state = ?"; p.push(filters.state); }
  q += " ORDER BY created_at DESC";
  return db.prepare(q).all(...p);
});

ipcMain.handle("delete-target", (_, id) => {
  db.prepare("DELETE FROM targets WHERE id = ?").run(id);
  return { success: true };
});

// Generate Excel report
ipcMain.handle("generate-report", async (_, { importId, reportType, filters, title }) => {
  const ExcelJS = require("exceljs");
  const settings = Object.fromEntries(
    db.prepare("SELECT key, value FROM app_settings").all().map((r) => [r.key, r.value])
  );
  const orgName = settings.org_name || "NBFC Branch Intelligence";
  const currency = settings.currency_symbol || "₹";
  const unit = settings.disbursement_unit || "Lakhs";

  // Get data
  let whereClause = "WHERE 1=1";
  const params = [];
  if (importId) { whereClause += " AND import_id = ?"; params.push(importId); }
  if (filters?.state) { whereClause += " AND state = ?"; params.push(filters.state); }
  if (filters?.region) { whereClause += " AND region = ?"; params.push(filters.region); }
  if (filters?.flag) { whereClause += " AND performance_flag = ?"; params.push(filters.flag); }

  const data = db.prepare(`SELECT * FROM branch_data ${whereClause} ORDER BY disbursement_pct ASC`).all(...params);

  // Create workbook
  const wb = new ExcelJS.Workbook();
  wb.creator = "NBFC Branch Intelligence";
  wb.created = new Date();

  // ── Sheet 1: Summary Dashboard ──
  const summarySheet = wb.addWorksheet("Dashboard Summary");
  summarySheet.properties.tabColor = { argb: "FF00D4FF" };

  // Title row
  summarySheet.mergeCells("A1:J1");
  const titleCell = summarySheet.getCell("A1");
  titleCell.value = title || `${orgName} — Branch Performance Report`;
  titleCell.font = { name: "Calibri", bold: true, size: 16, color: { argb: "FFFFFFFF" } };
  titleCell.alignment = { horizontal: "center", vertical: "middle" };
  titleCell.fill = { type: "pattern", pattern: "solid", fgColor: { argb: "FF07090F" } };
  summarySheet.getRow(1).height = 40;

  summarySheet.mergeCells("A2:J2");
  summarySheet.getCell("A2").value = `Generated: ${new Date().toLocaleString("en-IN")}  |  Total Branches: ${data.length}`;
  summarySheet.getCell("A2").font = { color: { argb: "FF8B95A9" }, size: 10 };
  summarySheet.getCell("A2").alignment = { horizontal: "center" };
  summarySheet.getCell("A2").fill = { type: "pattern", pattern: "solid", fgColor: { argb: "FF0D1117" } };
  summarySheet.getRow(2).height = 20;

  // Summary KPI row
  const totalDisb = data.reduce((s, r) => s + r.disbursement_actual, 0);
  const totalTarget = data.reduce((s, r) => s + r.disbursement_target, 0);
  const avgDisb = data.length ? data.reduce((s, r) => s + r.disbursement_pct, 0) / data.length : 0;
  const avgKyc = data.length ? data.reduce((s, r) => s + r.kyc_pct, 0) / data.length : 0;
  const avgColl = data.length ? data.reduce((s, r) => s + r.collection_efficiency, 0) / data.length : 0;
  const critical = data.filter((r) => r.performance_flag === "critical").length;
  const star = data.filter((r) => r.performance_flag === "star").length;

  const kpiData = [
    ["Total Branches", data.length],
    [`Total Disbursement (${unit})`, totalDisb.toFixed(2)],
    [`Total Target (${unit})`, totalTarget.toFixed(2)],
    ["Avg Disbursement %", `${avgDisb.toFixed(1)}%`],
    ["Avg KYC %", `${avgKyc.toFixed(1)}%`],
    ["Avg Collection %", `${avgColl.toFixed(1)}%`],
    ["Critical Branches", critical],
    ["Star Branches", star],
  ];

  summarySheet.addRow([]);
  summarySheet.addRow(["KEY PERFORMANCE INDICATORS"]);
  summarySheet.getRow(4).font = { bold: true, color: { argb: "FF00D4FF" } };
  summarySheet.getRow(4).height = 22;

  kpiData.forEach(([label, value]) => {
    const row = summarySheet.addRow([label, value]);
    row.getCell(1).font = { bold: true, color: { argb: "FF8B95A9" } };
    row.getCell(2).font = { bold: true };
    row.height = 18;
  });

  // ── Sheet 2: All Branches ──
  const branchSheet = wb.addWorksheet("Branch Performance");
  branchSheet.properties.tabColor = { argb: "FFF0A500" };

  const headers = [
    "Branch Code", "Branch Name", "State", "Region", "Employee",
    `Disb Target (${unit})`, `Disb Actual (${unit})`, "Disb %",
    "KYC Target", "KYC Actual", "KYC %",
    `Coll Target (${unit})`, `Coll Actual (${unit})`, "Coll Eff %",
    "PAR90 %", "Conversion %", `Run Rate (${unit})`, "Status"
  ];

  const headerRow = branchSheet.addRow(headers);
  headerRow.height = 28;
  headerRow.eachCell((cell) => {
    cell.font = { bold: true, color: { argb: "FFFFFFFF" }, size: 10 };
    cell.fill = { type: "pattern", pattern: "solid", fgColor: { argb: "FF0D1117" } };
    cell.alignment = { horizontal: "center", vertical: "middle", wrapText: true };
    cell.border = {
      bottom: { style: "thin", color: { argb: "FF1E2535" } },
    };
  });

  const flagColors = {
    critical: "FFFF4444",
    underperform: "FFFF8C00",
    par_alert: "FFFF6B35",
    star: "FF00D4FF",
    normal: "FF34D399",
  };
  const flagLabels = {
    critical: "🔴 Critical",
    underperform: "🟠 Under",
    par_alert: "⚠️ PAR Alert",
    star: "⭐ Star",
    normal: "✅ Normal",
  };

  data.forEach((row, idx) => {
    const dataRow = branchSheet.addRow([
      row.branch_code, row.branch_name, row.state, row.region, row.employee_name,
      row.disbursement_target, row.disbursement_actual, `${row.disbursement_pct}%`,
      row.kyc_target, row.kyc_actual, `${row.kyc_pct}%`,
      row.collection_target, row.collection_actual, `${row.collection_efficiency}%`,
      `${row.par90_pct}%`, `${row.conversion_ratio}%`, row.run_rate,
      flagLabels[row.performance_flag] || row.performance_flag,
    ]);

    dataRow.height = 20;
    const bgColor = idx % 2 === 0 ? "FF07090F" : "FF0D1117";
    dataRow.eachCell((cell) => {
      cell.fill = { type: "pattern", pattern: "solid", fgColor: { argb: bgColor } };
      cell.font = { color: { argb: "FFF0F4FF" }, size: 9 };
      cell.alignment = { horizontal: "center", vertical: "middle" };
    });

    // Color the status cell
    const statusCell = dataRow.getCell(18);
    statusCell.font = { color: { argb: flagColors[row.performance_flag] || "FFFFFFFF" }, bold: true, size: 9 };

    // Color disbursement % cell
    const disbCell = dataRow.getCell(8);
    if (row.disbursement_pct < 40) disbCell.font = { color: { argb: "FFFF4444" }, bold: true, size: 9 };
    else if (row.disbursement_pct < 70) disbCell.font = { color: { argb: "FFFF8C00" }, bold: true, size: 9 };
    else if (row.disbursement_pct >= 100) disbCell.font = { color: { argb: "FF00D4FF" }, bold: true, size: 9 };
  });

  // Set column widths
  branchSheet.columns = [
    { width: 14 }, { width: 22 }, { width: 14 }, { width: 16 }, { width: 20 },
    { width: 14 }, { width: 14 }, { width: 10 },
    { width: 12 }, { width: 12 }, { width: 10 },
    { width: 14 }, { width: 14 }, { width: 12 },
    { width: 10 }, { width: 12 }, { width: 12 }, { width: 14 },
  ];

  // Freeze header
  branchSheet.views = [{ state: "frozen", ySplit: 1 }];
  branchSheet.autoFilter = { from: "A1", to: `R1` };

  // ── Sheet 3: Underperformers ──
  if (reportType === "full" || reportType === "underperform") {
    const underSheet = wb.addWorksheet("🔴 Underperformers");
    underSheet.properties.tabColor = { argb: "FFFF4444" };
    const under = data.filter((r) => ["critical", "underperform"].includes(r.performance_flag));

    underSheet.addRow(["UNDERPERFORMING BRANCHES — Needs Immediate Attention"]);
    underSheet.getRow(1).font = { bold: true, color: { argb: "FFFF4444" }, size: 14 };
    underSheet.getRow(1).height = 30;
    underSheet.addRow([]);

    const uHeaders = ["Branch Code", "Branch Name", "State", "Region", `Disb Target`, `Disb Actual`, "Disb %", "KYC %", "PAR90 %", "Status"];
    const uHeaderRow = underSheet.addRow(uHeaders);
    uHeaderRow.height = 24;
    uHeaderRow.eachCell((cell) => {
      cell.font = { bold: true, color: { argb: "FFFFFFFF" }, size: 10 };
      cell.fill = { type: "pattern", pattern: "solid", fgColor: { argb: "FF1A0505" } };
      cell.alignment = { horizontal: "center", vertical: "middle" };
    });

    under.forEach((row) => {
      const r = underSheet.addRow([
        row.branch_code, row.branch_name, row.state, row.region,
        row.disbursement_target, row.disbursement_actual,
        `${row.disbursement_pct}%`, `${row.kyc_pct}%`, `${row.par90_pct}%`,
        flagLabels[row.performance_flag],
      ]);
      r.height = 18;
      r.getCell(7).font = { color: { argb: "FFFF4444" }, bold: true };
    });

    underSheet.columns = [{ width: 14 }, { width: 22 }, { width: 14 }, { width: 16 }, { width: 14 }, { width: 14 }, { width: 10 }, { width: 10 }, { width: 10 }, { width: 14 }];
  }

  // ── Sheet 4: State Summary ──
  const stateSheet = wb.addWorksheet("State Summary");
  stateSheet.properties.tabColor = { argb: "FF00D4FF" };

  const stateGroups = {};
  data.forEach((r) => {
    if (!stateGroups[r.state]) stateGroups[r.state] = [];
    stateGroups[r.state].push(r);
  });

  stateSheet.addRow(["STATE-WISE PERFORMANCE SUMMARY"]);
  stateSheet.getRow(1).font = { bold: true, color: { argb: "FF00D4FF" }, size: 14 };
  stateSheet.getRow(1).height = 30;
  stateSheet.addRow([]);

  const sHeaders = ["State", "Branches", `Total Target (${unit})`, `Total Actual (${unit})`, "Achievement %", "Avg KYC %", "Avg Coll %", "Critical", "Star"];
  const sHeaderRow = stateSheet.addRow(sHeaders);
  sHeaderRow.height = 24;
  sHeaderRow.eachCell((cell) => {
    cell.font = { bold: true, color: { argb: "FFFFFFFF" }, size: 10 };
    cell.fill = { type: "pattern", pattern: "solid", fgColor: { argb: "FF0D1117" } };
    cell.alignment = { horizontal: "center", vertical: "middle" };
  });

  Object.entries(stateGroups).forEach(([state, branches]) => {
    const tTarget = branches.reduce((s, b) => s + b.disbursement_target, 0);
    const tActual = branches.reduce((s, b) => s + b.disbursement_actual, 0);
    const avgD = branches.reduce((s, b) => s + b.disbursement_pct, 0) / branches.length;
    const avgK = branches.reduce((s, b) => s + b.kyc_pct, 0) / branches.length;
    const avgC = branches.reduce((s, b) => s + b.collection_efficiency, 0) / branches.length;
    const crit = branches.filter((b) => b.performance_flag === "critical").length;
    const starB = branches.filter((b) => b.performance_flag === "star").length;

    const r = stateSheet.addRow([
      state, branches.length, tTarget.toFixed(2), tActual.toFixed(2),
      `${avgD.toFixed(1)}%`, `${avgK.toFixed(1)}%`, `${avgC.toFixed(1)}%`, crit, starB,
    ]);
    r.height = 18;
    if (avgD < 70) r.getCell(5).font = { color: { argb: "FFFF4444" }, bold: true };
    else if (avgD >= 100) r.getCell(5).font = { color: { argb: "FF00D4FF" }, bold: true };
  });

  stateSheet.columns = [{ width: 18 }, { width: 12 }, { width: 18 }, { width: 18 }, { width: 16 }, { width: 14 }, { width: 14 }, { width: 12 }, { width: 10 }];

  // Save file
  const timestamp = new Date().toISOString().replace(/[:.]/g, "-").slice(0, 19);
  const fileName = `NBFC_Report_${timestamp}.xlsx`;
  const filePath = path.join(REPORTS_DIR, fileName);
  await wb.xlsx.writeFile(filePath);

  return { success: true, filePath, fileName };
});

// Open file in explorer
ipcMain.handle("open-file", (_, filePath) => {
  shell.showItemInFolder(filePath);
});

// Open reports folder
ipcMain.handle("open-reports-folder", () => {
  shell.openPath(REPORTS_DIR);
});

// App version
ipcMain.handle("get-app-info", () => ({
  version: app.getVersion(),
  dbPath: DB_PATH,
  reportsDir: REPORTS_DIR,
  userData: USER_DATA,
}));

// Backup DB
ipcMain.handle("backup-db", async () => {
  const timestamp = new Date().toISOString().replace(/[:.]/g, "-").slice(0, 19);
  const backupPath = path.join(BACKUPS_DIR, `backup_${timestamp}.db`);
  fs.copyFileSync(DB_PATH, backupPath);
  return { success: true, backupPath };
});
