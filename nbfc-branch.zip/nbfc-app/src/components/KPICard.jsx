export default function KPICard({ title, value, subtitle, color = "#00d4ff", icon: Icon, trend, small }) {
  return (
    <div
      className="glass fade-in"
      style={{ padding: small ? "14px 16px" : "18px 20px", transition: "border-color 0.2s" }}
      onMouseEnter={(e) => (e.currentTarget.style.borderColor = `${color}33`)}
      onMouseLeave={(e) => (e.currentTarget.style.borderColor = "rgba(30,37,53,0.9)")}
    >
      <div className="flex items-start justify-between gap-2">
        <div style={{ fontSize: small ? 11 : 12, color: "#8b95a9", fontFamily: "JetBrains Mono", letterSpacing: "0.05em", marginBottom: 8 }}>
          {title}
        </div>
        {Icon && (
          <div
            className="flex items-center justify-center rounded-lg flex-shrink-0"
            style={{ width: 32, height: 32, background: `${color}15`, border: `1px solid ${color}30` }}
          >
            <Icon size={15} color={color} />
          </div>
        )}
      </div>
      <div
        className="font-display font-bold"
        style={{ fontSize: small ? 22 : 28, color, lineHeight: 1, marginBottom: 4 }}
      >
        {value}
      </div>
      {subtitle && (
        <div style={{ fontSize: 11, color: "#4a5568", marginTop: 4 }}>
          {subtitle}
        </div>
      )}
      {trend !== undefined && (
        <div style={{ fontSize: 10, color: trend >= 0 ? "#34d399" : "#ff4444", marginTop: 4, fontFamily: "JetBrains Mono" }}>
          {trend >= 0 ? "▲" : "▼"} {Math.abs(trend).toFixed(1)}% vs target
        </div>
      )}
    </div>
  );
}
