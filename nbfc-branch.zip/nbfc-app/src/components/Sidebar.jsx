import { LayoutDashboard, Upload, Table2, Target, FileSpreadsheet, Settings, Database, ChevronDown, ChevronUp, Zap } from "lucide-react";
import { useState } from "react";

const NAV = [
  { id: "dashboard", label: "Dashboard", icon: LayoutDashboard },
  { id: "import", label: "Import Data", icon: Upload },
  { id: "branches", label: "Branch Analysis", icon: Table2 },
  { id: "targets", label: "Targets", icon: Target },
  { id: "reports", label: "Reports", icon: FileSpreadsheet },
  { id: "settings", label: "Settings", icon: Settings },
];

const FLAG_INFO = {
  critical: { label: "Critical", color: "#ff4444", bg: "rgba(255,68,68,0.1)" },
  underperform: { label: "Under", color: "#ff8c00", bg: "rgba(255,140,0,0.1)" },
  par_alert: { label: "PAR Alert", color: "#ff6b35", bg: "rgba(255,107,53,0.1)" },
  star: { label: "Star", color: "#00d4ff", bg: "rgba(0,212,255,0.1)" },
  normal: { label: "Normal", color: "#34d399", bg: "rgba(52,211,153,0.1)" },
};

export default function Sidebar({ currentPage, onNavigate, imports, activeImportId, onSelectImport }) {
  const [showImports, setShowImports] = useState(true);
  const activeImport = imports.find((i) => i.id === activeImportId);

  return (
    <aside
      className="flex flex-col border-r"
      style={{
        width: 220,
        minWidth: 220,
        background: "#0d1117",
        borderColor: "#1e2535",
        height: "100vh",
      }}
    >
      {/* Logo */}
      <div
        className="flex items-center gap-2.5 px-4"
        style={{ height: 56, borderBottom: "1px solid #1e2535" }}
      >
        <div
          className="flex items-center justify-center rounded-lg"
          style={{ width: 30, height: 30, background: "rgba(0,212,255,0.1)", border: "1px solid rgba(0,212,255,0.25)" }}
        >
          <Zap size={14} color="#00d4ff" />
        </div>
        <div>
          <div className="font-display text-xs font-semibold" style={{ color: "#f0f4ff", lineHeight: 1.2 }}>
            NBFC Intelligence
          </div>
          <div className="font-mono" style={{ fontSize: 9, color: "#4a5568" }}>
            v1.0 · Local & Secure
          </div>
        </div>
      </div>

      {/* Nav items */}
      <nav className="flex-1 overflow-y-auto p-3 space-y-1">
        {NAV.map(({ id, label, icon: Icon }) => {
          const active = currentPage === id;
          return (
            <button
              key={id}
              onClick={() => onNavigate(id)}
              className="w-full flex items-center gap-2.5 px-3 py-2.5 rounded-xl text-left transition-all"
              style={{
                background: active ? "rgba(0,212,255,0.08)" : "transparent",
                border: active ? "1px solid rgba(0,212,255,0.2)" : "1px solid transparent",
                color: active ? "#00d4ff" : "#8b95a9",
                fontSize: 13,
                fontWeight: active ? 600 : 400,
              }}
            >
              <Icon size={16} />
              {label}
            </button>
          );
        })}

        {/* Import selector */}
        {imports.length > 0 && (
          <div className="mt-4">
            <button
              onClick={() => setShowImports(!showImports)}
              className="w-full flex items-center justify-between px-3 py-1.5"
              style={{ color: "#4a5568", fontSize: 10 }}
            >
              <span className="font-mono uppercase tracking-widest">Data Sessions</span>
              {showImports ? <ChevronUp size={12} /> : <ChevronDown size={12} />}
            </button>

            {showImports && (
              <div className="space-y-1 mt-1">
                {imports.slice(0, 8).map((imp) => (
                  <button
                    key={imp.id}
                    onClick={() => onSelectImport(imp.id)}
                    className="w-full text-left px-3 py-2 rounded-lg transition-all"
                    style={{
                      background: activeImportId === imp.id ? "rgba(240,165,0,0.08)" : "transparent",
                      border: activeImportId === imp.id ? "1px solid rgba(240,165,0,0.2)" : "1px solid transparent",
                    }}
                  >
                    <div style={{ fontSize: 11, color: activeImportId === imp.id ? "#f0a500" : "#8b95a9", fontWeight: activeImportId === imp.id ? 600 : 400 }}>
                      {imp.period || imp.filename.replace(/\.[^.]+$/, "").slice(0, 20)}
                    </div>
                    <div className="font-mono" style={{ fontSize: 9, color: "#4a5568" }}>
                      {imp.record_count} branches · {new Date(imp.import_date).toLocaleDateString("en-IN")}
                    </div>
                  </button>
                ))}
              </div>
            )}
          </div>
        )}
      </nav>

      {/* Bottom: active session info */}
      {activeImport && (
        <div className="p-3" style={{ borderTop: "1px solid #1e2535" }}>
          <div style={{ fontSize: 9, color: "#4a5568", fontFamily: "JetBrains Mono", textTransform: "uppercase", letterSpacing: "0.1em", marginBottom: 4 }}>
            Active Session
          </div>
          <div style={{ fontSize: 11, color: "#f0a500", fontWeight: 600, marginBottom: 2 }}>
            {activeImport.period || "Current Data"}
          </div>
          <div style={{ fontSize: 10, color: "#4a5568" }}>
            {activeImport.record_count} branches loaded
          </div>
          <div style={{ fontSize: 10, color: "#4a5568" }}>
            <Database size={10} style={{ display: "inline", marginRight: 4 }} />
            100% Local · No Cloud
          </div>
        </div>
      )}
    </aside>
  );
}
