import { useState, useEffect } from "react";
import Sidebar from "./components/Sidebar";
import Dashboard from "./pages/Dashboard";
import Import from "./pages/Import";
import Branches from "./pages/Branches";
import Targets from "./pages/Targets";
import Reports from "./pages/Reports";
import Settings from "./pages/Settings";

const PAGES = {
  dashboard: Dashboard,
  import: Import,
  branches: Branches,
  targets: Targets,
  reports: Reports,
  settings: Settings,
};

export default function App() {
  const [page, setPage] = useState("dashboard");
  const [activeImportId, setActiveImportId] = useState(null);
  const [imports, setImports] = useState([]);

  const refreshImports = async () => {
    const data = await window.api.getImports();
    setImports(data);
    if (data.length && !activeImportId) setActiveImportId(data[0].id);
  };

  useEffect(() => { refreshImports(); }, []);

  const PageComponent = PAGES[page] || Dashboard;

  return (
    <div className="flex h-screen bg-canvas overflow-hidden">
      <Sidebar
        currentPage={page}
        onNavigate={setPage}
        imports={imports}
        activeImportId={activeImportId}
        onSelectImport={setActiveImportId}
      />
      <main className="flex-1 overflow-hidden">
        <PageComponent
          activeImportId={activeImportId}
          imports={imports}
          onImportSuccess={() => { refreshImports(); setPage("dashboard"); }}
          onNavigate={setPage}
        />
      </main>
    </div>
  );
}
