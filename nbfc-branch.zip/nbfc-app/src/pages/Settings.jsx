import { useState, useEffect } from "react";
import { Save, RotateCcw, Database, FolderOpen, Trash2, AlertTriangle, CheckCircle, Info } from "lucide-react";

export default function Settings() {
  const [config, setConfig] = useState(null);
  const [appSettings, setAppSettings] = useState({});
  const [appInfo, setAppInfo] = useState(null);
  const [imports, setImports] = useState([]);
  const [activeTab, setActiveTab] = useState("columns");
  const [saved, setSaved] = useState("");
  const [confirmDelete, setConfirmDelete] = useState(null);

  useEffect(() => {
    loadAll();
  }, []);

  const loadAll = async () => {
    const [cfg, st, info, imps] = await Promise.all([
      window.api.getConfig(),
      window.api.getSettings(),
      window.api.getAppInfo(),
      window.api.getImports(),
    ]);
    setConfig(cfg);
    setAppSettings(st);
    setAppInfo(info);
    setImports(imps);
  };

  const saveConfig = async () => {
    await window.api.saveConfig(config);
    setSaved("Column config saved!");
    setTimeout(() => setSaved(""), 2000);
  };

  const resetConfig = async () => {
    const fresh = await window.api.resetConfig();
    setConfig(fresh);
    setSaved("Config reset to defaults!");
    setTimeout(() => setSaved(""), 2000);
  };

  const saveSettings = async () => {
    await window.api.saveSettings(appSettings);
    setSaved("Settings saved!");
    setTimeout(() => setSaved(""), 2000);
  };

  const backup = async () => {
    const res = await window.api.backupDb();
    setSaved(`Backup created: ${res.backupPath.split("\\").pop().split("/").pop()}`);
    setTimeout(() => setSaved(""), 3000);
  };

  const deleteImport = async (id) => {
    await window.api.deleteImport(id);
    setConfirmDelete(null);
    loadAll();
  };

  if (!config) return (
    <div style={{ display: "flex", alignItems: "center", justifyContent: "center", height: "100vh", color: "#4a5568" }}>
      Loading...
    </div>
  );

  const TABS = [
    { id: "columns", label: "Column Mapping" },
    { id: "kpi", label: "KPI Settings" },
    { id: "general", label: "General" },
    { id: "data", label: "Data Management" },
  ];

  return (
    <div style={{ display: "flex", flexDirection: "column", height: "100vh", overflow: "hidden" }}>
      {/* Header */}
      <div style={{ padding: "16px 24px", borderBottom: "1px solid #1e2535", background: "#0d1117", flexShrink: 0 }}>
        <div style={{ fontFamily: "JetBrains Mono", fontSize: 10, color: "#4a5568", textTransform: "uppercase", letterSpacing: "0.1em" }}>Configuration</div>
        <h1 className="font-display" style={{ fontSize: 18, fontWeight: 700, color: "#f0f4ff" }}>Settings</h1>
      </div>

      {/* Tabs */}
      <div style={{ display: "flex", gap: 2, padding: "12px 24px 0", borderBottom: "1px solid #1e2535", background: "#0d1117", flexShrink: 0 }}>
        {TABS.map((tab) => (
          <button key={tab.id} onClick={() => setActiveTab(tab.id)}
            style={{
              padding: "8px 18px", borderRadius: "10px 10px 0 0", fontSize: 13, cursor: "pointer", transition: "all 0.15s", border: "none",
              background: activeTab === tab.id ? "#07090f" : "transparent",
              color: activeTab === tab.id ? "#00d4ff" : "#8b95a9",
              fontWeight: activeTab === tab.id ? 600 : 400,
              borderTop: activeTab === tab.id ? "1px solid #1e2535" : "1px solid transparent",
              borderLeft: activeTab === tab.id ? "1px solid #1e2535" : "1px solid transparent",
              borderRight: activeTab === tab.id ? "1px solid #1e2535" : "1px solid transparent",
            }}>
            {tab.label}
          </button>
        ))}
      </div>

      {saved && (
        <div style={{ padding: "10px 24px", background: "rgba(52,211,153,0.08)", borderBottom: "1px solid rgba(52,211,153,0.2)", display: "flex", alignItems: "center", gap: 8, color: "#34d399", fontSize: 12, flexShrink: 0 }}>
          <CheckCircle size={14} /> {saved}
        </div>
      )}

      <div className="content-scroll" style={{ padding: 24 }}>

        {/* Column Mapping Tab */}
        {activeTab === "columns" && (
          <div style={{ maxWidth: 900 }}>
            <div style={{ marginBottom: 20, padding: "14px 16px", background: "rgba(0,212,255,0.05)", border: "1px solid rgba(0,212,255,0.15)", borderRadius: 12, display: "flex", gap: 12 }}>
              <Info size={16} color="#00d4ff" style={{ flexShrink: 0, marginTop: 1 }} />
              <div style={{ fontSize: 13, color: "#8b95a9", lineHeight: 1.6 }}>
                <strong style={{ color: "#00d4ff" }}>How this works:</strong> When your Excel file columns change names, just update the "Excel Column Name" here to match the new header exactly. The system field (left) stays fixed. This means you never have to touch the code.
              </div>
            </div>

            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10, marginBottom: 20 }}>
              {Object.entries(config.mappings).map(([field, meta]) => (
                <div key={field} className="glass" style={{ padding: 14 }}>
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 8 }}>
                    <div>
                      <div style={{ fontSize: 12, fontWeight: 600, color: "#f0f4ff" }}>{meta.label}</div>
                      <div style={{ fontFamily: "JetBrains Mono", fontSize: 10, color: "#4a5568" }}>field: {field}</div>
                    </div>
                    {meta.required && (
                      <span style={{ padding: "2px 8px", background: "rgba(255,68,68,0.1)", border: "1px solid rgba(255,68,68,0.25)", borderRadius: 4, fontSize: 9, color: "#ff4444", fontFamily: "JetBrains Mono" }}>
                        REQUIRED
                      </span>
                    )}
                  </div>
                  <div style={{ fontSize: 10, color: "#4a5568", marginBottom: 6 }}>Excel column name:</div>
                  <input
                    className="input-dark"
                    value={meta.excelColumn}
                    onChange={(e) => setConfig({
                      ...config,
                      mappings: {
                        ...config.mappings,
                        [field]: { ...meta, excelColumn: e.target.value },
                      },
                    })}
                    style={{ fontSize: 12, padding: "8px 12px" }}
                  />
                </div>
              ))}
            </div>

            <div style={{ display: "flex", gap: 10 }}>
              <button className="btn-primary" onClick={saveConfig}><Save size={14} /> Save Column Config</button>
              <button className="btn-secondary" onClick={resetConfig}><RotateCcw size={14} /> Reset to Defaults</button>
            </div>
          </div>
        )}

        {/* KPI Settings Tab */}
        {activeTab === "kpi" && (
          <div style={{ maxWidth: 600 }}>
            <div className="glass" style={{ padding: 24, marginBottom: 20 }}>
              <h3 className="font-display" style={{ fontSize: 15, fontWeight: 600, color: "#f0f4ff", marginBottom: 4 }}>KPI Thresholds</h3>
              <p style={{ fontSize: 12, color: "#8b95a9", marginBottom: 20 }}>
                These thresholds control how branches are flagged automatically after each import.
              </p>

              <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
                <div>
                  <label style={{ display: "block", fontSize: 11, color: "#8b95a9", fontFamily: "JetBrains Mono", textTransform: "uppercase", letterSpacing: "0.08em", marginBottom: 6 }}>
                    Underperform Threshold (%)
                  </label>
                  <input className="input-dark" type="number" min={0} max={100}
                    value={appSettings.underperform_threshold || 70}
                    onChange={(e) => setAppSettings({ ...appSettings, underperform_threshold: e.target.value })} />
                  <div style={{ fontSize: 11, color: "#4a5568", marginTop: 4 }}>
                    Branches below this disbursement % are flagged as "Underperform". Default: 70%
                  </div>
                </div>

                <div>
                  <label style={{ display: "block", fontSize: 11, color: "#8b95a9", fontFamily: "JetBrains Mono", textTransform: "uppercase", letterSpacing: "0.08em", marginBottom: 6 }}>
                    PAR90 Alert Threshold (%)
                  </label>
                  <input className="input-dark" type="number" min={0} max={100} step="0.1"
                    value={appSettings.par90_threshold || 5}
                    onChange={(e) => setAppSettings({ ...appSettings, par90_threshold: e.target.value })} />
                  <div style={{ fontSize: 11, color: "#4a5568", marginTop: 4 }}>
                    Branches with PAR90 above this are flagged as "PAR Alert". Default: 5%
                  </div>
                </div>

                <div>
                  <label style={{ display: "block", fontSize: 11, color: "#8b95a9", fontFamily: "JetBrains Mono", textTransform: "uppercase", letterSpacing: "0.08em", marginBottom: 6 }}>
                    Working Days Per Month
                  </label>
                  <input className="input-dark" type="number" min={1} max={31}
                    value={appSettings.working_days_per_month || 25}
                    onChange={(e) => setAppSettings({ ...appSettings, working_days_per_month: e.target.value })} />
                  <div style={{ fontSize: 11, color: "#4a5568", marginTop: 4 }}>
                    Used for run-rate projections. Default: 25
                  </div>
                </div>
              </div>
            </div>
            <button className="btn-primary" onClick={saveSettings}><Save size={14} /> Save KPI Settings</button>
          </div>
        )}

        {/* General Tab */}
        {activeTab === "general" && (
          <div style={{ maxWidth: 600 }}>
            <div className="glass" style={{ padding: 24, marginBottom: 20 }}>
              <h3 className="font-display" style={{ fontSize: 15, fontWeight: 600, color: "#f0f4ff", marginBottom: 20 }}>Display Settings</h3>
              <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
                <div>
                  <label style={{ display: "block", fontSize: 11, color: "#8b95a9", fontFamily: "JetBrains Mono", textTransform: "uppercase", letterSpacing: "0.08em", marginBottom: 6 }}>Organisation Name</label>
                  <input className="input-dark" placeholder="e.g. Satin Creditcare Network Limited"
                    value={appSettings.org_name || ""}
                    onChange={(e) => setAppSettings({ ...appSettings, org_name: e.target.value })} />
                  <div style={{ fontSize: 11, color: "#4a5568", marginTop: 4 }}>Shown in reports and dashboard header</div>
                </div>
                <div>
                  <label style={{ display: "block", fontSize: 11, color: "#8b95a9", fontFamily: "JetBrains Mono", textTransform: "uppercase", letterSpacing: "0.08em", marginBottom: 6 }}>Currency Symbol</label>
                  <input className="input-dark" style={{ maxWidth: 100 }} placeholder="₹"
                    value={appSettings.currency_symbol || "₹"}
                    onChange={(e) => setAppSettings({ ...appSettings, currency_symbol: e.target.value })} />
                </div>
                <div>
                  <label style={{ display: "block", fontSize: 11, color: "#8b95a9", fontFamily: "JetBrains Mono", textTransform: "uppercase", letterSpacing: "0.08em", marginBottom: 6 }}>Disbursement Unit Label</label>
                  <input className="input-dark" style={{ maxWidth: 150 }} placeholder="Lakhs"
                    value={appSettings.disbursement_unit || "Lakhs"}
                    onChange={(e) => setAppSettings({ ...appSettings, disbursement_unit: e.target.value })} />
                  <div style={{ fontSize: 11, color: "#4a5568", marginTop: 4 }}>e.g. Lakhs, Crores, Thousands</div>
                </div>
              </div>
            </div>
            <button className="btn-primary" onClick={saveSettings}><Save size={14} /> Save General Settings</button>

            {appInfo && (
              <div className="glass" style={{ padding: 20, marginTop: 20 }}>
                <div style={{ fontSize: 11, color: "#4a5568", fontFamily: "JetBrains Mono", textTransform: "uppercase", letterSpacing: "0.08em", marginBottom: 12 }}>App Info</div>
                <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
                  {[
                    ["Version", `v${appInfo.version}`],
                    ["Database", appInfo.dbPath],
                    ["Reports Folder", appInfo.reportsDir],
                  ].map(([k, v]) => (
                    <div key={k} style={{ display: "flex", gap: 12 }}>
                      <span style={{ fontSize: 11, color: "#4a5568", minWidth: 100, fontFamily: "JetBrains Mono" }}>{k}</span>
                      <span style={{ fontSize: 11, color: "#8b95a9", wordBreak: "break-all" }}>{v}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}

        {/* Data Management Tab */}
        {activeTab === "data" && (
          <div style={{ maxWidth: 700 }}>
            <div className="glass" style={{ padding: 20, marginBottom: 20 }}>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}>
                <div>
                  <h3 className="font-display" style={{ fontSize: 15, fontWeight: 600, color: "#f0f4ff" }}>Imported Sessions</h3>
                  <p style={{ fontSize: 12, color: "#8b95a9", marginTop: 2 }}>Manage your imported data. Deleting a session removes all its branch data.</p>
                </div>
                <button className="btn-secondary" style={{ fontSize: 12, padding: "8px 14px" }} onClick={backup}>
                  <Database size={13} /> Backup Database
                </button>
              </div>

              {imports.length === 0 ? (
                <div style={{ textAlign: "center", padding: 40, color: "#4a5568" }}>No data imported yet.</div>
              ) : (
                <table className="data-table">
                  <thead>
                    <tr>
                      <th>Period / Name</th>
                      <th>File</th>
                      <th>Branches</th>
                      <th>Type</th>
                      <th>Imported On</th>
                      <th>Notes</th>
                      <th></th>
                    </tr>
                  </thead>
                  <tbody>
                    {imports.map((imp) => (
                      <tr key={imp.id}>
                        <td style={{ padding: "10px 12px", fontWeight: 600, color: "#f0a500" }}>{imp.period || "—"}</td>
                        <td style={{ padding: "10px 12px", fontFamily: "JetBrains Mono", fontSize: 10, color: "#8b95a9" }}>{imp.filename}</td>
                        <td style={{ padding: "10px 12px", fontFamily: "JetBrains Mono", fontSize: 12, color: "#00d4ff" }}>{imp.record_count}</td>
                        <td style={{ padding: "10px 12px", fontSize: 11, color: "#8b95a9" }}>—</td>
                        <td style={{ padding: "10px 12px", fontSize: 11, color: "#4a5568", fontFamily: "JetBrains Mono" }}>
                          {new Date(imp.import_date).toLocaleString("en-IN")}
                        </td>
                        <td style={{ padding: "10px 12px", fontSize: 11, color: "#8b95a9" }}>{imp.notes || "—"}</td>
                        <td style={{ padding: "10px 12px" }}>
                          {confirmDelete === imp.id ? (
                            <div style={{ display: "flex", gap: 6 }}>
                              <button style={{ padding: "4px 10px", background: "rgba(255,68,68,0.15)", border: "1px solid #ff4444", color: "#ff4444", borderRadius: 6, fontSize: 11, cursor: "pointer" }}
                                onClick={() => deleteImport(imp.id)}>Delete</button>
                              <button style={{ padding: "4px 10px", background: "transparent", border: "1px solid #1e2535", color: "#8b95a9", borderRadius: 6, fontSize: 11, cursor: "pointer" }}
                                onClick={() => setConfirmDelete(null)}>Cancel</button>
                            </div>
                          ) : (
                            <button className="btn-danger" onClick={() => setConfirmDelete(imp.id)}>
                              <Trash2 size={12} />
                            </button>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              )}
            </div>

            <div className="glass" style={{ padding: 20, border: "1px solid rgba(255,165,0,0.2)" }}>
              <div style={{ display: "flex", gap: 10, alignItems: "flex-start" }}>
                <AlertTriangle size={16} color="#f0a500" style={{ marginTop: 1, flexShrink: 0 }} />
                <div>
                  <div style={{ fontSize: 13, fontWeight: 600, color: "#f0a500", marginBottom: 4 }}>Data Privacy Note</div>
                  <p style={{ fontSize: 12, color: "#8b95a9", lineHeight: 1.6 }}>
                    All data is stored locally in a SQLite database on your machine at the path shown above. 
                    No data is ever transmitted over the internet. The app works completely offline.
                    Use the Backup function regularly to keep a copy of your database.
                  </p>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
