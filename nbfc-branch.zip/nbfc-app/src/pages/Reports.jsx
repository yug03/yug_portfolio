import { useState, useEffect } from "react";
import { FileSpreadsheet, Download, FolderOpen, CheckCircle, Loader, Trash2 } from "lucide-react";

export default function Reports({ activeImportId, imports }) {
  const [filterOptions, setFilterOptions] = useState({ states: [], regions: [] });
  const [settings, setSettings] = useState({});
  const [generating, setGenerating] = useState(false);
  const [lastReport, setLastReport] = useState(null);
  const [error, setError] = useState("");

  const [reportForm, setReportForm] = useState({
    selectedImportId: activeImportId || "",
    reportType: "full",
    title: "",
    filterState: "",
    filterRegion: "",
    filterFlag: "",
  });

  useEffect(() => {
    setReportForm((f) => ({ ...f, selectedImportId: activeImportId || "" }));
  }, [activeImportId]);

  useEffect(() => {
    if (reportForm.selectedImportId) {
      window.api.getFilterOptions(reportForm.selectedImportId).then(setFilterOptions);
    }
    window.api.getSettings().then(setSettings);
  }, [reportForm.selectedImportId]);

  const generate = async () => {
    setGenerating(true);
    setError("");
    setLastReport(null);
    try {
      const res = await window.api.generateReport({
        importId: reportForm.selectedImportId ? parseInt(reportForm.selectedImportId) : null,
        reportType: reportForm.reportType,
        title: reportForm.title || undefined,
        filters: {
          state: reportForm.filterState || undefined,
          region: reportForm.filterRegion || undefined,
          flag: reportForm.filterFlag || undefined,
        },
      });
      if (res.success) {
        setLastReport(res);
      } else {
        setError("Report generation failed.");
      }
    } catch (e) {
      setError(String(e));
    }
    setGenerating(false);
  };

  const REPORT_TYPES = [
    { id: "full", label: "Full Report", description: "All branches + state summary + underperformer sheet", color: "#00d4ff" },
    { id: "underperform", label: "Underperformers Only", description: "Critical and underperforming branches", color: "#ff4444" },
    { id: "state", label: "State Summary", description: "State-wise aggregated performance", color: "#34d399" },
    { id: "star", label: "Star Performers", description: "Branches at or above target", color: "#f0a500" },
  ];

  const FLAG_OPTIONS = [
    { value: "", label: "All Branches" },
    { value: "critical", label: "🔴 Critical Only" },
    { value: "underperform", label: "🟠 Underperforming" },
    { value: "par_alert", label: "⚠️ PAR Alert" },
    { value: "star", label: "⭐ Star Performers" },
    { value: "normal", label: "✅ Normal" },
  ];

  const activeImport = imports.find((i) => i.id === parseInt(reportForm.selectedImportId));

  return (
    <div className="content-scroll" style={{ padding: 24 }}>
      <div style={{ marginBottom: 24 }}>
        <div style={{ fontFamily: "JetBrains Mono", fontSize: 10, color: "#00d4ff", textTransform: "uppercase", letterSpacing: "0.1em", marginBottom: 4 }}>Report Generator</div>
        <h1 className="font-display" style={{ fontSize: 22, fontWeight: 700, color: "#f0f4ff" }}>Generate Excel Reports</h1>
        <p style={{ color: "#8b95a9", fontSize: 13, marginTop: 4 }}>
          Generate formatted, colour-coded Excel reports saved directly to your machine. Ready to share with Business Heads.
        </p>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 340px", gap: 24, alignItems: "start" }}>

        {/* Left: Report builder */}
        <div style={{ display: "flex", flexDirection: "column", gap: 20 }}>

          {/* Report type selection */}
          <div className="glass" style={{ padding: 20 }}>
            <div style={{ fontSize: 11, color: "#4a5568", fontFamily: "JetBrains Mono", textTransform: "uppercase", letterSpacing: "0.08em", marginBottom: 14 }}>Report Type</div>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
              {REPORT_TYPES.map((rt) => (
                <button
                  key={rt.id}
                  onClick={() => setReportForm({ ...reportForm, reportType: rt.id })}
                  style={{
                    padding: "14px 16px", borderRadius: 12, textAlign: "left", cursor: "pointer", transition: "all 0.2s",
                    background: reportForm.reportType === rt.id ? `${rt.color}10` : "transparent",
                    border: `1px solid ${reportForm.reportType === rt.id ? rt.color + "40" : "#1e2535"}`,
                  }}
                >
                  <div style={{ fontSize: 13, fontWeight: 600, color: reportForm.reportType === rt.id ? rt.color : "#f0f4ff", marginBottom: 4 }}>
                    {rt.label}
                  </div>
                  <div style={{ fontSize: 11, color: "#8b95a9" }}>{rt.description}</div>
                </button>
              ))}
            </div>
          </div>

          {/* Filters & Options */}
          <div className="glass" style={{ padding: 20 }}>
            <div style={{ fontSize: 11, color: "#4a5568", fontFamily: "JetBrains Mono", textTransform: "uppercase", letterSpacing: "0.08em", marginBottom: 14 }}>Filters & Options</div>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 14 }}>

              <div>
                <label style={{ display: "block", fontSize: 10, color: "#8b95a9", fontFamily: "JetBrains Mono", textTransform: "uppercase", letterSpacing: "0.08em", marginBottom: 5 }}>Data Session</label>
                <select className="input-dark" value={reportForm.selectedImportId}
                  onChange={(e) => setReportForm({ ...reportForm, selectedImportId: e.target.value })}>
                  <option value="">All sessions (combined)</option>
                  {imports.map((imp) => (
                    <option key={imp.id} value={imp.id}>
                      {imp.period || imp.filename} ({imp.record_count} branches)
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label style={{ display: "block", fontSize: 10, color: "#8b95a9", fontFamily: "JetBrains Mono", textTransform: "uppercase", letterSpacing: "0.08em", marginBottom: 5 }}>Branch Status Filter</label>
                <select className="input-dark" value={reportForm.filterFlag}
                  onChange={(e) => setReportForm({ ...reportForm, filterFlag: e.target.value })}>
                  {FLAG_OPTIONS.map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
                </select>
              </div>

              <div>
                <label style={{ display: "block", fontSize: 10, color: "#8b95a9", fontFamily: "JetBrains Mono", textTransform: "uppercase", letterSpacing: "0.08em", marginBottom: 5 }}>State Filter</label>
                <select className="input-dark" value={reportForm.filterState}
                  onChange={(e) => setReportForm({ ...reportForm, filterState: e.target.value })}>
                  <option value="">All States</option>
                  {filterOptions.states.map((s) => <option key={s}>{s}</option>)}
                </select>
              </div>

              <div>
                <label style={{ display: "block", fontSize: 10, color: "#8b95a9", fontFamily: "JetBrains Mono", textTransform: "uppercase", letterSpacing: "0.08em", marginBottom: 5 }}>Region Filter</label>
                <select className="input-dark" value={reportForm.filterRegion}
                  onChange={(e) => setReportForm({ ...reportForm, filterRegion: e.target.value })}>
                  <option value="">All Regions</option>
                  {filterOptions.regions.map((r) => <option key={r}>{r}</option>)}
                </select>
              </div>

              <div style={{ gridColumn: "span 2" }}>
                <label style={{ display: "block", fontSize: 10, color: "#8b95a9", fontFamily: "JetBrains Mono", textTransform: "uppercase", letterSpacing: "0.08em", marginBottom: 5 }}>Custom Report Title (optional)</label>
                <input className="input-dark" placeholder={`${settings.org_name || "NBFC"} — Branch Performance Report`}
                  value={reportForm.title} onChange={(e) => setReportForm({ ...reportForm, title: e.target.value })} />
              </div>
            </div>
          </div>

          {/* Generate button */}
          {error && (
            <div style={{ padding: "12px 16px", background: "rgba(255,68,68,0.08)", border: "1px solid rgba(255,68,68,0.25)", borderRadius: 10, color: "#ff4444", fontSize: 13 }}>
              {error}
            </div>
          )}

          <button className="btn-primary" onClick={generate} disabled={generating} style={{ padding: "14px 24px", fontSize: 14, justifyContent: "center" }}>
            {generating
              ? <><Loader size={16} className="spin" /> Generating Report...</>
              : <><FileSpreadsheet size={16} /> Generate Excel Report</>
            }
          </button>

          {/* Success */}
          {lastReport && (
            <div className="glass fade-in" style={{ padding: 20, border: "1px solid rgba(52,211,153,0.25)" }}>
              <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 12 }}>
                <CheckCircle size={20} color="#34d399" />
                <div>
                  <div style={{ fontWeight: 600, color: "#34d399", fontSize: 14 }}>Report Generated!</div>
                  <div style={{ fontSize: 11, color: "#8b95a9", fontFamily: "JetBrains Mono" }}>{lastReport.fileName}</div>
                </div>
              </div>
              <div style={{ display: "flex", gap: 10 }}>
                <button className="btn-primary" onClick={() => window.api.openFile(lastReport.filePath)} style={{ fontSize: 13 }}>
                  <Download size={14} /> Open File
                </button>
                <button className="btn-secondary" onClick={() => window.api.openReportsFolder()} style={{ fontSize: 13 }}>
                  <FolderOpen size={14} /> Open Folder
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Right: What's included */}
        <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
          <div className="glass" style={{ padding: 20 }}>
            <div style={{ fontSize: 11, color: "#4a5568", fontFamily: "JetBrains Mono", textTransform: "uppercase", letterSpacing: "0.08em", marginBottom: 14 }}>What's Included</div>
            {[
              { title: "Dashboard Summary", desc: "Key KPI numbers, total disbursement, critical count", color: "#00d4ff" },
              { title: "Branch Performance", desc: "All branches with colour-coded % bars and status flags", color: "#f0a500" },
              { title: "Underperformers Sheet", desc: "Separate tab for critical + underperforming branches", color: "#ff4444" },
              { title: "State-wise Summary", desc: "Aggregate view grouped by state", color: "#34d399" },
            ].map((item) => (
              <div key={item.title} style={{ display: "flex", gap: 12, marginBottom: 12, paddingBottom: 12, borderBottom: "1px solid #1e2535" }}>
                <div style={{ width: 3, borderRadius: 2, background: item.color, flexShrink: 0 }} />
                <div>
                  <div style={{ fontSize: 12, fontWeight: 600, color: "#f0f4ff", marginBottom: 2 }}>{item.title}</div>
                  <div style={{ fontSize: 11, color: "#8b95a9" }}>{item.desc}</div>
                </div>
              </div>
            ))}
            <div style={{ fontSize: 11, color: "#4a5568", fontFamily: "JetBrains Mono", marginTop: 4 }}>
              Reports saved to your local AppData/reports folder
            </div>
          </div>

          <div className="glass" style={{ padding: 20 }}>
            <div style={{ fontSize: 11, color: "#4a5568", fontFamily: "JetBrains Mono", textTransform: "uppercase", letterSpacing: "0.08em", marginBottom: 14 }}>Report Storage</div>
            <p style={{ fontSize: 12, color: "#8b95a9", marginBottom: 12, lineHeight: 1.6 }}>
              All reports are saved to your local machine. Access them anytime from the reports folder.
            </p>
            <button className="btn-secondary" style={{ width: "100%", justifyContent: "center" }}
              onClick={() => window.api.openReportsFolder()}>
              <FolderOpen size={14} /> Open Reports Folder
            </button>
          </div>

          {activeImport && (
            <div className="glass" style={{ padding: 20 }}>
              <div style={{ fontSize: 11, color: "#4a5568", fontFamily: "JetBrains Mono", textTransform: "uppercase", letterSpacing: "0.08em", marginBottom: 10 }}>Active Session</div>
              <div style={{ fontSize: 13, color: "#f0a500", fontWeight: 600 }}>{activeImport.period || activeImport.filename}</div>
              <div style={{ fontSize: 11, color: "#8b95a9", marginTop: 4 }}>{activeImport.record_count} branches</div>
              <div style={{ fontSize: 10, color: "#4a5568", fontFamily: "JetBrains Mono", marginTop: 2 }}>
                Imported: {new Date(activeImport.import_date).toLocaleString("en-IN")}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
