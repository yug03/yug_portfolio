import { useState } from "react";
import { Upload, FileSpreadsheet, AlertCircle, CheckCircle, Info, ChevronRight } from "lucide-react";

export default function Import({ onImportSuccess }) {
  const [step, setStep] = useState(1); // 1: pick file, 2: preview & config, 3: importing, 4: done
  const [filePath, setFilePath] = useState(null);
  const [preview, setPreview] = useState(null);
  const [config, setConfig] = useState(null);
  const [form, setForm] = useState({
    period: "",
    periodType: "monthly",
    notes: "",
    daysElapsed: 15,
  });
  const [error, setError] = useState("");
  const [result, setResult] = useState(null);

  const pickFile = async () => {
    const fp = await window.api.pickExcelFile();
    if (!fp) return;
    setFilePath(fp);
    setError("");

    const [prev, cfg] = await Promise.all([
      window.api.previewExcel(fp),
      window.api.getConfig(),
    ]);
    setPreview(prev);
    setConfig(cfg);
    setStep(2);
  };

  const doImport = async () => {
    if (!form.period.trim()) { setError("Please enter a period name (e.g. 'April 2025')"); return; }
    setStep(3);
    setError("");
    const res = await window.api.importExcel({
      filePath,
      period: form.period,
      periodType: form.periodType,
      notes: form.notes,
      daysElapsed: parseInt(form.daysElapsed) || 15,
    });

    if (res.success) {
      setResult(res);
      setStep(4);
    } else {
      setError(res.error || "Import failed");
      setStep(2);
    }
  };

  const reset = () => {
    setStep(1); setFilePath(null); setPreview(null); setConfig(null);
    setForm({ period: "", periodType: "monthly", notes: "", daysElapsed: 15 });
    setError(""); setResult(null);
  };

  // Check which configured columns exist in the Excel file
  const colStatus = config && preview
    ? Object.entries(config.mappings).map(([field, meta]) => ({
        field,
        label: meta.label,
        excelCol: meta.excelColumn,
        found: preview.headers.includes(meta.excelColumn),
        required: meta.required,
      }))
    : [];

  const missingRequired = colStatus.filter((c) => c.required && !c.found);

  return (
    <div className="content-scroll" style={{ padding: 24 }}>
      {/* Header */}
      <div style={{ marginBottom: 24 }}>
        <div style={{ fontFamily: "JetBrains Mono", fontSize: 11, color: "#00d4ff", textTransform: "uppercase", letterSpacing: "0.1em", marginBottom: 4 }}>
          Data Import
        </div>
        <h1 className="font-display" style={{ fontSize: 22, fontWeight: 700, color: "#f0f4ff" }}>
          Import Branch Performance Data
        </h1>
        <p style={{ color: "#8b95a9", fontSize: 13, marginTop: 4 }}>
          Import your Excel/CSV file. All data is processed and stored locally — nothing leaves your machine.
        </p>
      </div>

      {/* Step indicators */}
      <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 28 }}>
        {["Select File", "Configure", "Import", "Complete"].map((label, i) => {
          const s = i + 1;
          const active = step === s;
          const done = step > s;
          return (
            <div key={s} style={{ display: "flex", alignItems: "center", gap: 8 }}>
              <div style={{
                width: 28, height: 28, borderRadius: "50%", display: "flex", alignItems: "center", justifyContent: "center",
                background: done ? "#34d399" : active ? "#00d4ff" : "#1e2535",
                color: done || active ? "#07090f" : "#4a5568",
                fontSize: 12, fontWeight: 700,
              }}>
                {done ? "✓" : s}
              </div>
              <span style={{ fontSize: 12, color: active ? "#f0f4ff" : "#4a5568" }}>{label}</span>
              {i < 3 && <ChevronRight size={14} color="#1e2535" />}
            </div>
          );
        })}
      </div>

      {error && (
        <div style={{ marginBottom: 20, padding: "12px 16px", background: "rgba(255,68,68,0.08)", border: "1px solid rgba(255,68,68,0.25)", borderRadius: 10, color: "#ff4444", fontSize: 13, display: "flex", alignItems: "center", gap: 8 }}>
          <AlertCircle size={16} />
          {error}
        </div>
      )}

      {/* Step 1: File picker */}
      {step === 1 && (
        <div className="glass fade-in" style={{ padding: 40, textAlign: "center", maxWidth: 520 }}>
          <div style={{ width: 64, height: 64, background: "rgba(0,212,255,0.08)", border: "1px solid rgba(0,212,255,0.2)", borderRadius: 16, display: "flex", alignItems: "center", justifyContent: "center", margin: "0 auto 20px" }}>
            <FileSpreadsheet size={28} color="#00d4ff" />
          </div>
          <h2 className="font-display" style={{ fontSize: 18, fontWeight: 600, color: "#f0f4ff", marginBottom: 8 }}>
            Select Your Excel File
          </h2>
          <p style={{ color: "#8b95a9", fontSize: 13, marginBottom: 28, lineHeight: 1.6 }}>
            Supports .xlsx, .xls, and .csv formats. Make sure your file has column headers in the first row.
          </p>
          <button className="btn-primary" onClick={pickFile}>
            <Upload size={16} />
            Browse and Select File
          </button>
          <p style={{ color: "#4a5568", fontSize: 11, marginTop: 20, fontFamily: "JetBrains Mono" }}>
            🔒 File is read locally. Never uploaded or transmitted.
          </p>
        </div>
      )}

      {/* Step 2: Preview + configure */}
      {step === 2 && preview && config && (
        <div className="fade-in" style={{ display: "grid", gridTemplateColumns: "1fr 340px", gap: 20 }}>

          {/* Left: Column mapping status */}
          <div className="glass" style={{ padding: 20 }}>
            <h3 className="font-display" style={{ fontSize: 15, fontWeight: 600, color: "#f0f4ff", marginBottom: 4 }}>
              Column Mapping Check
            </h3>
            <p style={{ color: "#8b95a9", fontSize: 12, marginBottom: 16 }}>
              File: <span style={{ color: "#00d4ff", fontFamily: "JetBrains Mono" }}>{filePath.split("\\").pop().split("/").pop()}</span>
              <span style={{ color: "#4a5568", marginLeft: 8 }}>{preview.totalRows} rows · {preview.headers.length} columns found</span>
            </p>

            {missingRequired.length > 0 && (
              <div style={{ marginBottom: 16, padding: "10px 14px", background: "rgba(255,68,68,0.08)", border: "1px solid rgba(255,68,68,0.2)", borderRadius: 10 }}>
                <div style={{ color: "#ff4444", fontSize: 12, fontWeight: 600, marginBottom: 4 }}>Missing Required Columns</div>
                <div style={{ color: "#8b95a9", fontSize: 12 }}>
                  Go to Settings → Column Config to update column names to match your file.
                </div>
              </div>
            )}

            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 6 }}>
              {colStatus.map((c) => (
                <div key={c.field} style={{
                  display: "flex", alignItems: "center", gap: 8, padding: "8px 12px",
                  background: c.found ? "rgba(52,211,153,0.05)" : "rgba(255,68,68,0.05)",
                  border: `1px solid ${c.found ? "rgba(52,211,153,0.2)" : "rgba(255,68,68,0.2)"}`,
                  borderRadius: 8,
                }}>
                  {c.found
                    ? <CheckCircle size={13} color="#34d399" />
                    : <AlertCircle size={13} color={c.required ? "#ff4444" : "#4a5568"} />
                  }
                  <div>
                    <div style={{ fontSize: 11, color: c.found ? "#f0f4ff" : "#8b95a9" }}>{c.label}</div>
                    <div style={{ fontSize: 10, color: "#4a5568", fontFamily: "JetBrains Mono" }}>
                      → "{c.excelCol}"
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* Extra columns from file not in mapping */}
            {preview.headers.filter((h) => !Object.values(config.mappings).map((m) => m.excelColumn).includes(h)).length > 0 && (
              <div style={{ marginTop: 14, padding: "10px 14px", background: "rgba(240,165,0,0.05)", border: "1px solid rgba(240,165,0,0.15)", borderRadius: 10 }}>
                <div style={{ color: "#f0a500", fontSize: 11, marginBottom: 6, display: "flex", alignItems: "center", gap: 6 }}>
                  <Info size={12} />
                  Extra columns (will be stored as custom data)
                </div>
                <div style={{ display: "flex", flexWrap: "wrap", gap: 4 }}>
                  {preview.headers
                    .filter((h) => !Object.values(config.mappings).map((m) => m.excelColumn).includes(h))
                    .map((h) => (
                      <span key={h} style={{ padding: "2px 8px", background: "rgba(240,165,0,0.08)", border: "1px solid rgba(240,165,0,0.2)", borderRadius: 4, fontSize: 10, color: "#f0a500", fontFamily: "JetBrains Mono" }}>
                        {h}
                      </span>
                    ))}
                </div>
              </div>
            )}

            {/* Data preview table */}
            <div style={{ marginTop: 16 }}>
              <div style={{ fontSize: 11, color: "#4a5568", fontFamily: "JetBrains Mono", marginBottom: 8 }}>FIRST 5 ROWS PREVIEW</div>
              <div style={{ overflowX: "auto", borderRadius: 8, border: "1px solid #1e2535" }}>
                <table className="data-table" style={{ fontSize: 10 }}>
                  <thead>
                    <tr>
                      {preview.headers.slice(0, 8).map((h) => (
                        <th key={h} style={{ padding: "6px 10px" }}>{h}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {preview.preview.map((row, i) => (
                      <tr key={i}>
                        {preview.headers.slice(0, 8).map((h) => (
                          <td key={h} style={{ padding: "5px 10px", fontSize: 10 }}>{String(row[h] ?? "")}</td>
                        ))}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>

          {/* Right: Import settings */}
          <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
            <div className="glass" style={{ padding: 20 }}>
              <h3 className="font-display" style={{ fontSize: 15, fontWeight: 600, color: "#f0f4ff", marginBottom: 16 }}>
                Import Settings
              </h3>

              <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
                <div>
                  <label style={{ display: "block", fontSize: 11, color: "#8b95a9", fontFamily: "JetBrains Mono", textTransform: "uppercase", letterSpacing: "0.08em", marginBottom: 6 }}>
                    Period Name *
                  </label>
                  <input
                    className="input-dark"
                    placeholder="e.g. April 2025 or 12-Apr Daily"
                    value={form.period}
                    onChange={(e) => setForm({ ...form, period: e.target.value })}
                  />
                </div>

                <div>
                  <label style={{ display: "block", fontSize: 11, color: "#8b95a9", fontFamily: "JetBrains Mono", textTransform: "uppercase", letterSpacing: "0.08em", marginBottom: 6 }}>
                    Report Type
                  </label>
                  <select
                    className="input-dark"
                    value={form.periodType}
                    onChange={(e) => setForm({ ...form, periodType: e.target.value })}
                  >
                    <option value="monthly">Monthly Performance</option>
                    <option value="daily">Daily Performance</option>
                    <option value="weekly">Weekly Performance</option>
                    <option value="custom">Custom Period</option>
                  </select>
                </div>

                {form.periodType !== "monthly" && (
                  <div>
                    <label style={{ display: "block", fontSize: 11, color: "#8b95a9", fontFamily: "JetBrains Mono", textTransform: "uppercase", letterSpacing: "0.08em", marginBottom: 6 }}>
                      Days Elapsed (for Run Rate)
                    </label>
                    <input
                      className="input-dark"
                      type="number"
                      min={1}
                      max={31}
                      value={form.daysElapsed}
                      onChange={(e) => setForm({ ...form, daysElapsed: e.target.value })}
                    />
                    <div style={{ fontSize: 10, color: "#4a5568", marginTop: 4 }}>
                      Used to project current actuals to month-end run rate
                    </div>
                  </div>
                )}

                <div>
                  <label style={{ display: "block", fontSize: 11, color: "#8b95a9", fontFamily: "JetBrains Mono", textTransform: "uppercase", letterSpacing: "0.08em", marginBottom: 6 }}>
                    Notes (optional)
                  </label>
                  <textarea
                    className="input-dark"
                    placeholder="Any notes about this data import..."
                    rows={3}
                    value={form.notes}
                    onChange={(e) => setForm({ ...form, notes: e.target.value })}
                    style={{ resize: "none" }}
                  />
                </div>
              </div>
            </div>

            <div style={{ display: "flex", gap: 10 }}>
              <button className="btn-secondary" onClick={reset} style={{ flex: 1 }}>
                ← Back
              </button>
              <button className="btn-primary" onClick={doImport} style={{ flex: 2 }}>
                Import {preview.totalRows} Rows →
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Step 3: Loading */}
      {step === 3 && (
        <div className="glass fade-in" style={{ padding: 60, textAlign: "center", maxWidth: 400 }}>
          <div className="spin" style={{ width: 40, height: 40, border: "3px solid #1e2535", borderTopColor: "#00d4ff", borderRadius: "50%", margin: "0 auto 20px" }} />
          <h3 className="font-display" style={{ fontSize: 18, fontWeight: 600, color: "#f0f4ff", marginBottom: 8 }}>
            Processing Data...
          </h3>
          <p style={{ color: "#8b95a9", fontSize: 13 }}>
            Calculating KPIs, flagging performance, and storing locally.
          </p>
        </div>
      )}

      {/* Step 4: Success */}
      {step === 4 && result && (
        <div className="glass fade-in" style={{ padding: 40, textAlign: "center", maxWidth: 440 }}>
          <div style={{ width: 64, height: 64, background: "rgba(52,211,153,0.1)", border: "1px solid rgba(52,211,153,0.25)", borderRadius: 16, display: "flex", alignItems: "center", justifyContent: "center", margin: "0 auto 20px" }}>
            <CheckCircle size={30} color="#34d399" />
          </div>
          <h2 className="font-display" style={{ fontSize: 20, fontWeight: 700, color: "#f0f4ff", marginBottom: 8 }}>
            Import Successful!
          </h2>
          <p style={{ color: "#8b95a9", fontSize: 13, marginBottom: 24, lineHeight: 1.6 }}>
            <strong style={{ color: "#00d4ff" }}>{result.recordCount} branch records</strong> imported and KPIs calculated.
            All data is stored locally on your machine.
          </p>
          <div style={{ display: "flex", gap: 10, justifyContent: "center" }}>
            <button className="btn-secondary" onClick={reset}>
              Import Another File
            </button>
            <button className="btn-primary" onClick={onImportSuccess}>
              View Dashboard →
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
