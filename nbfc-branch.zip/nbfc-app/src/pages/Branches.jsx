import { useState, useEffect, useCallback } from "react";
import { Search, Filter, Download, RefreshCw, TrendingUp, TrendingDown } from "lucide-react";

const FLAG_META = {
  critical: { label: "🔴 Critical", color: "#ff4444" },
  underperform: { label: "🟠 Underperform", color: "#ff8c00" },
  par_alert: { label: "⚠️ PAR Alert", color: "#ff6b35" },
  star: { label: "⭐ Star", color: "#00d4ff" },
  normal: { label: "✅ Normal", color: "#34d399" },
};

export default function Branches({ activeImportId }) {
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filterOptions, setFilterOptions] = useState({ states: [], regions: [] });
  const [settings, setSettings] = useState({});
  const [filters, setFilters] = useState({
    search: "", state: "", region: "", flag: "",
  });
  const [sortBy, setSortBy] = useState("disbursement_pct");
  const [sortDir, setSortDir] = useState("asc");
  const [selectedRows, setSelectedRows] = useState(new Set());

  useEffect(() => { load(); }, [activeImportId, filters]);

  const load = async () => {
    setLoading(true);
    const [rows, opts, st] = await Promise.all([
      window.api.getBranchData({ importId: activeImportId, ...filters }),
      window.api.getFilterOptions(activeImportId),
      window.api.getSettings(),
    ]);
    setData(rows);
    setFilterOptions(opts);
    setSettings(st);
    setLoading(false);
  };

  const handleSort = (col) => {
    if (sortBy === col) setSortDir(d => d === "asc" ? "desc" : "asc");
    else { setSortBy(col); setSortDir("asc"); }
  };

  const sorted = [...data].sort((a, b) => {
    const av = a[sortBy]; const bv = b[sortBy];
    if (typeof av === "number") return sortDir === "asc" ? av - bv : bv - av;
    return sortDir === "asc" ? String(av).localeCompare(String(bv)) : String(bv).localeCompare(String(av));
  });

  const SortHeader = ({ col, label }) => (
    <th style={{ padding: "10px 12px", cursor: "pointer", whiteSpace: "nowrap" }} onClick={() => handleSort(col)}>
      <div style={{ display: "flex", alignItems: "center", gap: 4 }}>
        {label}
        {sortBy === col && (sortDir === "asc" ? <TrendingUp size={10} color="#00d4ff" /> : <TrendingDown size={10} color="#00d4ff" />)}
      </div>
    </th>
  );

  const PctCell = ({ value, warn = 70, danger = 40 }) => {
    const color = value >= 100 ? "#00d4ff" : value >= warn ? "#34d399" : value >= danger ? "#f0a500" : "#ff4444";
    return (
      <td style={{ padding: "10px 12px" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
          <div className="progress-bar" style={{ width: 50 }}>
            <div className="progress-fill" style={{ width: `${Math.min(value, 100)}%`, background: color }} />
          </div>
          <span style={{ color, fontWeight: value < danger ? 700 : 400, fontSize: 12, fontFamily: "JetBrains Mono" }}>
            {value?.toFixed(1)}%
          </span>
        </div>
      </td>
    );
  };

  const currency = settings.currency_symbol || "₹";
  const unit = settings.disbursement_unit || "L";

  const clearFilters = () => setFilters({ search: "", state: "", region: "", flag: "" });
  const hasFilters = Object.values(filters).some(Boolean);

  return (
    <div style={{ display: "flex", flexDirection: "column", height: "100vh", overflow: "hidden" }}>
      {/* Header bar */}
      <div style={{ padding: "16px 24px", borderBottom: "1px solid #1e2535", background: "#0d1117", display: "flex", alignItems: "center", gap: 16, flexShrink: 0 }}>
        <div style={{ flex: 1 }}>
          <div style={{ fontFamily: "JetBrains Mono", fontSize: 10, color: "#4a5568", textTransform: "uppercase", letterSpacing: "0.1em" }}>
            Branch Analysis
          </div>
          <h1 className="font-display" style={{ fontSize: 18, fontWeight: 700, color: "#f0f4ff" }}>
            {data.length} Branches
            {hasFilters && <span style={{ color: "#f0a500", fontSize: 13, fontWeight: 400, marginLeft: 8 }}>(filtered)</span>}
          </h1>
        </div>

        {/* Search */}
        <div style={{ position: "relative" }}>
          <Search size={14} color="#4a5568" style={{ position: "absolute", left: 12, top: "50%", transform: "translateY(-50%)" }} />
          <input
            className="input-dark"
            style={{ paddingLeft: 34, width: 220 }}
            placeholder="Search branch, code, name..."
            value={filters.search}
            onChange={(e) => setFilters({ ...filters, search: e.target.value })}
          />
        </div>

        {/* Filters */}
        <select className="input-dark" style={{ width: 130 }} value={filters.state}
          onChange={(e) => setFilters({ ...filters, state: e.target.value })}>
          <option value="">All States</option>
          {filterOptions.states.map((s) => <option key={s}>{s}</option>)}
        </select>

        <select className="input-dark" style={{ width: 130 }} value={filters.region}
          onChange={(e) => setFilters({ ...filters, region: e.target.value })}>
          <option value="">All Regions</option>
          {filterOptions.regions.map((r) => <option key={r}>{r}</option>)}
        </select>

        <select className="input-dark" style={{ width: 140 }} value={filters.flag}
          onChange={(e) => setFilters({ ...filters, flag: e.target.value })}>
          <option value="">All Status</option>
          {Object.entries(FLAG_META).map(([k, v]) => <option key={k} value={k}>{v.label}</option>)}
        </select>

        {hasFilters && (
          <button className="btn-secondary" style={{ padding: "8px 14px", fontSize: 12 }} onClick={clearFilters}>
            Clear ×
          </button>
        )}

        <button className="btn-secondary" style={{ padding: "8px 12px" }} onClick={load}>
          <RefreshCw size={14} />
        </button>
      </div>

      {/* Quick filter pills */}
      <div style={{ padding: "10px 24px", borderBottom: "1px solid #1e2535", background: "#0d1117", display: "flex", gap: 8, flexShrink: 0 }}>
        <span style={{ fontSize: 11, color: "#4a5568", alignSelf: "center", fontFamily: "JetBrains Mono" }}>QUICK:</span>
        {Object.entries(FLAG_META).map(([flag, meta]) => {
          const count = data.filter((r) => r.performance_flag === flag).length;
          return (
            <button
              key={flag}
              onClick={() => setFilters({ ...filters, flag: filters.flag === flag ? "" : flag })}
              style={{
                padding: "4px 12px", borderRadius: 999, fontSize: 11,
                background: filters.flag === flag ? `${meta.color}20` : "transparent",
                border: `1px solid ${filters.flag === flag ? meta.color : "#1e2535"}`,
                color: filters.flag === flag ? meta.color : "#8b95a9",
                cursor: "pointer", transition: "all 0.15s",
              }}
            >
              {meta.label} ({count})
            </button>
          );
        })}
      </div>

      {/* Table */}
      <div style={{ flex: 1, overflowY: "auto", overflowX: "auto" }}>
        {loading ? (
          <div style={{ display: "flex", alignItems: "center", justifyContent: "center", height: 300, color: "#4a5568" }}>
            <div className="spin" style={{ width: 28, height: 28, border: "2px solid #1e2535", borderTopColor: "#00d4ff", borderRadius: "50%", marginRight: 12 }} />
            Loading...
          </div>
        ) : sorted.length === 0 ? (
          <div style={{ textAlign: "center", padding: 60, color: "#4a5568" }}>
            <Filter size={32} style={{ margin: "0 auto 16px", opacity: 0.4 }} />
            <div>No branches found matching your filters</div>
          </div>
        ) : (
          <table className="data-table">
            <thead>
              <tr>
                <SortHeader col="branch_code" label="Code" />
                <SortHeader col="branch_name" label="Branch Name" />
                <SortHeader col="state" label="State" />
                <SortHeader col="region" label="Region" />
                <th>Employee</th>
                <SortHeader col="disbursement_target" label={`Target (${unit})`} />
                <SortHeader col="disbursement_actual" label={`Actual (${unit})`} />
                <SortHeader col="disbursement_pct" label="Disb %" />
                <SortHeader col="kyc_pct" label="KYC %" />
                <SortHeader col="collection_efficiency" label="Coll %" />
                <SortHeader col="par90_pct" label="PAR90 %" />
                <SortHeader col="conversion_ratio" label="Conv %" />
                <SortHeader col="run_rate" label={`Run Rate (${unit})`} />
                <SortHeader col="performance_flag" label="Status" />
              </tr>
            </thead>
            <tbody>
              {sorted.map((row) => {
                const flagMeta = FLAG_META[row.performance_flag] || { label: row.performance_flag, color: "#8b95a9" };
                return (
                  <tr key={row.id}>
                    <td style={{ padding: "10px 12px", fontFamily: "JetBrains Mono", fontSize: 11, color: "#8b95a9" }}>{row.branch_code}</td>
                    <td style={{ padding: "10px 12px", fontWeight: 500, color: "#f0f4ff", whiteSpace: "nowrap" }}>{row.branch_name}</td>
                    <td style={{ padding: "10px 12px", color: "#8b95a9" }}>{row.state}</td>
                    <td style={{ padding: "10px 12px", color: "#8b95a9" }}>{row.region}</td>
                    <td style={{ padding: "10px 12px", color: "#8b95a9", fontSize: 11 }}>{row.employee_name}</td>
                    <td style={{ padding: "10px 12px", fontFamily: "JetBrains Mono", fontSize: 11, color: "#8b95a9" }}>{row.disbursement_target?.toFixed(1)}</td>
                    <td style={{ padding: "10px 12px", fontFamily: "JetBrains Mono", fontSize: 11, color: "#f0f4ff", fontWeight: 600 }}>{row.disbursement_actual?.toFixed(1)}</td>
                    <PctCell value={row.disbursement_pct} />
                    <PctCell value={row.kyc_pct} />
                    <PctCell value={row.collection_efficiency} />
                    <td style={{ padding: "10px 12px" }}>
                      <span style={{ color: row.par90_pct > 5 ? "#ff4444" : "#34d399", fontFamily: "JetBrains Mono", fontSize: 11, fontWeight: row.par90_pct > 5 ? 700 : 400 }}>
                        {row.par90_pct?.toFixed(2)}%
                      </span>
                    </td>
                    <td style={{ padding: "10px 12px", fontFamily: "JetBrains Mono", fontSize: 11, color: "#8b95a9" }}>{row.conversion_ratio?.toFixed(1)}%</td>
                    <td style={{ padding: "10px 12px", fontFamily: "JetBrains Mono", fontSize: 11, color: "#f0a500" }}>{row.run_rate?.toFixed(1)}</td>
                    <td style={{ padding: "10px 12px" }}>
                      <span style={{
                        padding: "3px 10px", borderRadius: 999, fontSize: 11,
                        background: `${flagMeta.color}15`,
                        border: `1px solid ${flagMeta.color}30`,
                        color: flagMeta.color, fontWeight: 600, whiteSpace: "nowrap",
                      }}>
                        {flagMeta.label}
                      </span>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}
