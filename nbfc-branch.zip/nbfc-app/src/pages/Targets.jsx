import { useState, useEffect } from "react";
import { Plus, Trash2, Target, Calendar, MapPin } from "lucide-react";

export default function Targets({ activeImportId }) {
  const [targets, setTargets] = useState([]);
  const [branches, setBranches] = useState([]);
  const [filterOptions, setFilterOptions] = useState({ states: [], regions: [] });
  const [settings, setSettings] = useState({});
  const [showForm, setShowForm] = useState(false);
  const [filterType, setFilterType] = useState("");
  const [form, setForm] = useState({
    branch_code: "", branch_name: "", state: "", region: "",
    target_type: "monthly", period: "",
    disbursement_target: "", kyc_target: "", collection_target: "", notes: "",
  });
  const [saving, setSaving] = useState(false);

  useEffect(() => { load(); }, [activeImportId, filterType]);

  const load = async () => {
    const [t, b, opts, st] = await Promise.all([
      window.api.getTargets({ target_type: filterType || undefined }),
      window.api.getBranchData({ importId: activeImportId }),
      window.api.getFilterOptions(activeImportId),
      window.api.getSettings(),
    ]);
    setTargets(t);
    setBranches(b);
    setFilterOptions(opts);
    setSettings(st);
  };

  const fillFromBranch = (branchCode) => {
    const b = branches.find((br) => br.branch_code === branchCode);
    if (b) {
      setForm((f) => ({
        ...f,
        branch_code: b.branch_code,
        branch_name: b.branch_name,
        state: b.state || "",
        region: b.region || "",
      }));
    }
  };

  const save = async () => {
    if (!form.branch_code || !form.period) return;
    setSaving(true);
    await window.api.saveTarget({
      ...form,
      disbursement_target: parseFloat(form.disbursement_target) || 0,
      kyc_target: parseFloat(form.kyc_target) || 0,
      collection_target: parseFloat(form.collection_target) || 0,
    });
    setSaving(false);
    setShowForm(false);
    setForm({ branch_code: "", branch_name: "", state: "", region: "", target_type: "monthly", period: "", disbursement_target: "", kyc_target: "", collection_target: "", notes: "" });
    load();
  };

  const del = async (id) => {
    await window.api.deleteTarget(id);
    load();
  };

  const currency = settings.currency_symbol || "₹";
  const unit = settings.disbursement_unit || "Lakhs";

  const TYPE_META = {
    monthly: { label: "Monthly", color: "#00d4ff" },
    daily: { label: "Daily", color: "#f0a500" },
    weekly: { label: "Weekly", color: "#34d399" },
    custom: { label: "Custom", color: "#8b95a9" },
  };

  return (
    <div style={{ display: "flex", flexDirection: "column", height: "100vh", overflow: "hidden" }}>
      {/* Header */}
      <div style={{ padding: "16px 24px", borderBottom: "1px solid #1e2535", background: "#0d1117", display: "flex", alignItems: "center", gap: 16, flexShrink: 0 }}>
        <div style={{ flex: 1 }}>
          <div style={{ fontFamily: "JetBrains Mono", fontSize: 10, color: "#4a5568", textTransform: "uppercase", letterSpacing: "0.1em" }}>Target Management</div>
          <h1 className="font-display" style={{ fontSize: 18, fontWeight: 700, color: "#f0f4ff" }}>Branch Targets</h1>
        </div>

        <select className="input-dark" style={{ width: 160 }} value={filterType} onChange={(e) => setFilterType(e.target.value)}>
          <option value="">All Target Types</option>
          <option value="monthly">Monthly</option>
          <option value="daily">Daily</option>
          <option value="weekly">Weekly</option>
          <option value="custom">Custom</option>
        </select>

        <button className="btn-primary" onClick={() => setShowForm(true)}>
          <Plus size={15} /> Add Target
        </button>
      </div>

      {/* Info banner */}
      <div style={{ padding: "12px 24px", background: "rgba(240,165,0,0.05)", borderBottom: "1px solid rgba(240,165,0,0.1)", display: "flex", gap: 12, alignItems: "flex-start" }}>
        <Target size={14} color="#f0a500" style={{ marginTop: 1, flexShrink: 0 }} />
        <div style={{ fontSize: 12, color: "#8b95a9", lineHeight: 1.5 }}>
          Set <strong style={{ color: "#f0a500" }}>daily targets</strong> for specific underperforming branches or focus regions — on top of their monthly targets. 
          These help track daily cadence for branches where you need closer monitoring, new market entry, or special push campaigns.
        </div>
      </div>

      {/* Add Target Form */}
      {showForm && (
        <div style={{ padding: "20px 24px", borderBottom: "1px solid #1e2535", background: "#0d1117" }}>
          <div className="glass" style={{ padding: 20, maxWidth: 900 }}>
            <h3 className="font-display" style={{ fontSize: 14, fontWeight: 600, color: "#f0f4ff", marginBottom: 16 }}>
              New Target
            </h3>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr 1fr", gap: 14 }}>

              <div>
                <label style={{ display: "block", fontSize: 10, color: "#8b95a9", fontFamily: "JetBrains Mono", textTransform: "uppercase", letterSpacing: "0.08em", marginBottom: 5 }}>Branch (from imported data)</label>
                <select className="input-dark" value={form.branch_code}
                  onChange={(e) => { setForm({ ...form, branch_code: e.target.value }); fillFromBranch(e.target.value); }}>
                  <option value="">-- Select Branch --</option>
                  {branches.map((b) => <option key={b.id} value={b.branch_code}>{b.branch_code} — {b.branch_name}</option>)}
                </select>
              </div>

              <div>
                <label style={{ display: "block", fontSize: 10, color: "#8b95a9", fontFamily: "JetBrains Mono", textTransform: "uppercase", letterSpacing: "0.08em", marginBottom: 5 }}>Or Enter Branch Code</label>
                <input className="input-dark" placeholder="e.g. BR001" value={form.branch_code}
                  onChange={(e) => setForm({ ...form, branch_code: e.target.value })} />
              </div>

              <div>
                <label style={{ display: "block", fontSize: 10, color: "#8b95a9", fontFamily: "JetBrains Mono", textTransform: "uppercase", letterSpacing: "0.08em", marginBottom: 5 }}>Target Type *</label>
                <select className="input-dark" value={form.target_type}
                  onChange={(e) => setForm({ ...form, target_type: e.target.value })}>
                  <option value="monthly">Monthly</option>
                  <option value="daily">Daily</option>
                  <option value="weekly">Weekly</option>
                  <option value="custom">Custom Period</option>
                </select>
              </div>

              <div>
                <label style={{ display: "block", fontSize: 10, color: "#8b95a9", fontFamily: "JetBrains Mono", textTransform: "uppercase", letterSpacing: "0.08em", marginBottom: 5 }}>Period *</label>
                <input className="input-dark" placeholder="e.g. 12-Apr-25 or April 2025"
                  value={form.period} onChange={(e) => setForm({ ...form, period: e.target.value })} />
              </div>

              <div>
                <label style={{ display: "block", fontSize: 10, color: "#8b95a9", fontFamily: "JetBrains Mono", textTransform: "uppercase", letterSpacing: "0.08em", marginBottom: 5 }}>State</label>
                <input className="input-dark" placeholder="State" value={form.state}
                  onChange={(e) => setForm({ ...form, state: e.target.value })} />
              </div>

              <div>
                <label style={{ display: "block", fontSize: 10, color: "#8b95a9", fontFamily: "JetBrains Mono", textTransform: "uppercase", letterSpacing: "0.08em", marginBottom: 5 }}>Region</label>
                <input className="input-dark" placeholder="Region" value={form.region}
                  onChange={(e) => setForm({ ...form, region: e.target.value })} />
              </div>

              <div>
                <label style={{ display: "block", fontSize: 10, color: "#8b95a9", fontFamily: "JetBrains Mono", textTransform: "uppercase", letterSpacing: "0.08em", marginBottom: 5 }}>Disbursement Target ({unit})</label>
                <input className="input-dark" type="number" placeholder="0.00"
                  value={form.disbursement_target} onChange={(e) => setForm({ ...form, disbursement_target: e.target.value })} />
              </div>

              <div>
                <label style={{ display: "block", fontSize: 10, color: "#8b95a9", fontFamily: "JetBrains Mono", textTransform: "uppercase", letterSpacing: "0.08em", marginBottom: 5 }}>KYC Target</label>
                <input className="input-dark" type="number" placeholder="0"
                  value={form.kyc_target} onChange={(e) => setForm({ ...form, kyc_target: e.target.value })} />
              </div>

              <div>
                <label style={{ display: "block", fontSize: 10, color: "#8b95a9", fontFamily: "JetBrains Mono", textTransform: "uppercase", letterSpacing: "0.08em", marginBottom: 5 }}>Collection Target ({unit})</label>
                <input className="input-dark" type="number" placeholder="0.00"
                  value={form.collection_target} onChange={(e) => setForm({ ...form, collection_target: e.target.value })} />
              </div>

              <div style={{ gridColumn: "span 3" }}>
                <label style={{ display: "block", fontSize: 10, color: "#8b95a9", fontFamily: "JetBrains Mono", textTransform: "uppercase", letterSpacing: "0.08em", marginBottom: 5 }}>Notes / Reason</label>
                <input className="input-dark" placeholder="e.g. New market entry — Faridabad cluster, daily targets for 2 weeks"
                  value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} />
              </div>
            </div>

            <div style={{ display: "flex", gap: 10, marginTop: 16 }}>
              <button className="btn-secondary" onClick={() => setShowForm(false)}>Cancel</button>
              <button className="btn-primary" onClick={save} disabled={saving || !form.branch_code || !form.period}>
                {saving ? "Saving..." : "Save Target"}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Targets table */}
      <div style={{ flex: 1, overflowY: "auto" }}>
        {targets.length === 0 ? (
          <div style={{ textAlign: "center", padding: 60, color: "#4a5568" }}>
            <Target size={36} style={{ margin: "0 auto 16px", opacity: 0.4 }} />
            <div style={{ fontSize: 14, marginBottom: 8 }}>No targets set yet</div>
            <div style={{ fontSize: 12 }}>Add monthly or daily targets for specific branches to track them closely.</div>
          </div>
        ) : (
          <table className="data-table">
            <thead>
              <tr>
                <th>Branch Code</th>
                <th>Branch Name</th>
                <th>State / Region</th>
                <th>Type</th>
                <th>Period</th>
                <th>Disb Target ({unit})</th>
                <th>KYC Target</th>
                <th>Coll Target ({unit})</th>
                <th>Notes</th>
                <th>Added On</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              {targets.map((t) => {
                const meta = TYPE_META[t.target_type] || TYPE_META.custom;
                return (
                  <tr key={t.id}>
                    <td style={{ padding: "10px 12px", fontFamily: "JetBrains Mono", fontSize: 11, color: "#8b95a9" }}>{t.branch_code}</td>
                    <td style={{ padding: "10px 12px", color: "#f0f4ff", fontWeight: 500 }}>{t.branch_name || "—"}</td>
                    <td style={{ padding: "10px 12px", fontSize: 11, color: "#8b95a9" }}>
                      <div style={{ display: "flex", alignItems: "center", gap: 4 }}>
                        <MapPin size={10} color="#4a5568" />
                        {[t.state, t.region].filter(Boolean).join(" · ") || "—"}
                      </div>
                    </td>
                    <td style={{ padding: "10px 12px" }}>
                      <span style={{ padding: "3px 10px", borderRadius: 999, fontSize: 10, fontWeight: 600, background: `${meta.color}15`, border: `1px solid ${meta.color}30`, color: meta.color }}>
                        {meta.label}
                      </span>
                    </td>
                    <td style={{ padding: "10px 12px", fontFamily: "JetBrains Mono", fontSize: 11, color: "#f0a500" }}>
                      <Calendar size={10} style={{ display: "inline", marginRight: 4 }} />
                      {t.period}
                    </td>
                    <td style={{ padding: "10px 12px", fontFamily: "JetBrains Mono", fontSize: 11, color: "#f0f4ff" }}>{t.disbursement_target?.toFixed(2)}</td>
                    <td style={{ padding: "10px 12px", fontFamily: "JetBrains Mono", fontSize: 11, color: "#f0f4ff" }}>{t.kyc_target}</td>
                    <td style={{ padding: "10px 12px", fontFamily: "JetBrains Mono", fontSize: 11, color: "#f0f4ff" }}>{t.collection_target?.toFixed(2)}</td>
                    <td style={{ padding: "10px 12px", fontSize: 11, color: "#8b95a9", maxWidth: 200, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{t.notes || "—"}</td>
                    <td style={{ padding: "10px 12px", fontSize: 10, color: "#4a5568", fontFamily: "JetBrains Mono" }}>
                      {new Date(t.created_at).toLocaleDateString("en-IN")}
                    </td>
                    <td style={{ padding: "10px 12px" }}>
                      <button className="btn-danger" onClick={() => del(t.id)}>
                        <Trash2 size={12} />
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}
