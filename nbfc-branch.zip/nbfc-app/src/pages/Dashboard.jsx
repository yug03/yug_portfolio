import { useState, useEffect } from "react";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, Legend } from "recharts";
import KPICard from "../components/KPICard";
import { TrendingUp, Users, AlertTriangle, Star, Activity, Wallet, Target, Zap } from "lucide-react";

const FLAG_COLORS = {
  critical: "#ff4444",
  underperform: "#ff8c00",
  par_alert: "#ff6b35",
  star: "#00d4ff",
  normal: "#34d399",
};

const FLAG_LABELS = {
  critical: "Critical",
  underperform: "Underperform",
  par_alert: "PAR Alert",
  star: "Star",
  normal: "Normal",
};

const CustomTooltip = ({ active, payload, label }) => {
  if (!active || !payload?.length) return null;
  return (
    <div className="glass" style={{ padding: "10px 14px", fontSize: 12 }}>
      <div style={{ color: "#8b95a9", marginBottom: 4, fontFamily: "JetBrains Mono", fontSize: 10 }}>{label}</div>
      {payload.map((p) => (
        <div key={p.name} style={{ color: p.color || "#f0f4ff" }}>
          {p.name}: <strong>{typeof p.value === "number" ? p.value.toFixed(1) : p.value}</strong>
        </div>
      ))}
    </div>
  );
};

export default function Dashboard({ activeImportId, imports, onNavigate }) {
  const [summary, setSummary] = useState(null);
  const [loading, setLoading] = useState(true);
  const [settings, setSettings] = useState({});

  useEffect(() => {
    load();
  }, [activeImportId]);

  const load = async () => {
    setLoading(true);
    const [s, st] = await Promise.all([
      window.api.getDashboardSummary(activeImportId),
      window.api.getSettings(),
    ]);
    setSummary(s);
    setSettings(st);
    setLoading(false);
  };

  if (loading) {
    return (
      <div className="content-scroll flex items-center justify-center" style={{ height: "100vh" }}>
        <div style={{ textAlign: "center", color: "#8b95a9" }}>
          <div className="spin" style={{ width: 32, height: 32, border: "2px solid #1e2535", borderTopColor: "#00d4ff", borderRadius: "50%", margin: "0 auto 16px" }} />
          <div style={{ fontFamily: "JetBrains Mono", fontSize: 12 }}>Loading intelligence data...</div>
        </div>
      </div>
    );
  }

  if (!summary?.summary || !imports.length) {
    return (
      <div className="content-scroll flex flex-col items-center justify-center" style={{ height: "100vh", gap: 20 }}>
        <div style={{ width: 64, height: 64, background: "rgba(0,212,255,0.08)", border: "1px solid rgba(0,212,255,0.2)", borderRadius: 16, display: "flex", alignItems: "center", justifyContent: "center" }}>
          <Zap size={28} color="#00d4ff" />
        </div>
        <div style={{ textAlign: "center" }}>
          <h2 className="font-display" style={{ fontSize: 22, fontWeight: 700, color: "#f0f4ff", marginBottom: 8 }}>
            Welcome to NBFC Branch Intelligence
          </h2>
          <p style={{ color: "#8b95a9", fontSize: 14, maxWidth: 380, lineHeight: 1.6 }}>
            Import your branch performance Excel file to start monitoring KPIs, identifying underperformers, and generating reports.
          </p>
        </div>
        <button className="btn-primary" onClick={() => onNavigate("import")}>
          Import Branch Data
        </button>
        <div style={{ fontFamily: "JetBrains Mono", fontSize: 11, color: "#4a5568" }}>
          🔒 All data stays on your machine. No cloud. No internet required.
        </div>
      </div>
    );
  }

  const { summary: s, stateBreakdown, flagDistribution } = summary;
  const currency = settings.currency_symbol || "₹";
  const unit = settings.disbursement_unit || "Lakhs";

  const pieData = flagDistribution.map((f) => ({
    name: FLAG_LABELS[f.performance_flag] || f.performance_flag,
    value: f.count,
    color: FLAG_COLORS[f.performance_flag] || "#8b95a9",
  }));

  const stateChartData = (stateBreakdown || []).slice(0, 10).map((s) => ({
    name: s.state || "Unknown",
    Achievement: parseFloat(s.avg_disb?.toFixed(1) || 0),
    Disbursement: parseFloat(s.total_disb?.toFixed(2) || 0),
  }));

  const achievementPct = s.avg_disbursement_pct?.toFixed(1) || 0;

  return (
    <div className="content-scroll" style={{ padding: 24, background: "#07090f" }}>
      {/* Header */}
      <div className="fade-in" style={{ marginBottom: 24 }}>
        <div style={{ display: "flex", alignItems: "flex-start", justifyContent: "space-between" }}>
          <div>
            <div style={{ fontFamily: "JetBrains Mono", fontSize: 11, color: "#00d4ff", textTransform: "uppercase", letterSpacing: "0.1em", marginBottom: 4 }}>
              Branch Intelligence Dashboard
            </div>
            <h1 className="font-display" style={{ fontSize: 24, fontWeight: 700, color: "#f0f4ff" }}>
              {settings.org_name || "Performance Overview"}
            </h1>
          </div>
          <div style={{ textAlign: "right" }}>
            <div style={{ fontSize: 12, color: "#8b95a9" }}>
              {s.total_branches} Branches Monitored
            </div>
            <div style={{ fontFamily: "JetBrains Mono", fontSize: 10, color: "#4a5568", marginTop: 2 }}>
              {new Date().toLocaleDateString("en-IN", { weekday: "long", year: "numeric", month: "long", day: "numeric" })}
            </div>
          </div>
        </div>
      </div>

      {/* Alert banner if critical branches exist */}
      {s.critical_count > 0 && (
        <div className="fade-in" style={{ marginBottom: 20, padding: "12px 16px", background: "rgba(255,68,68,0.08)", border: "1px solid rgba(255,68,68,0.25)", borderRadius: 12, display: "flex", alignItems: "center", gap: 12 }}>
          <AlertTriangle size={18} color="#ff4444" />
          <div>
            <span style={{ color: "#ff4444", fontWeight: 600, fontSize: 13 }}>
              {s.critical_count} Critical Branch{s.critical_count > 1 ? "es" : ""} Require Immediate Attention
            </span>
            <span style={{ color: "#8b95a9", fontSize: 12, marginLeft: 8 }}>
              Below 40% disbursement achievement
            </span>
          </div>
          <button
            className="btn-secondary"
            style={{ marginLeft: "auto", padding: "6px 14px", fontSize: 12 }}
            onClick={() => onNavigate("branches")}
          >
            View Branches →
          </button>
        </div>
      )}

      {/* KPI Cards */}
      <div className="kpi-grid fade-in" style={{ marginBottom: 24 }}>
        <KPICard
          title="Avg Disbursement"
          value={`${achievementPct}%`}
          subtitle={`${currency}${(s.total_disbursement || 0).toFixed(1)} ${unit} actual`}
          color={achievementPct >= 80 ? "#34d399" : achievementPct >= 60 ? "#f0a500" : "#ff4444"}
          icon={TrendingUp}
          trend={achievementPct - 100}
        />
        <KPICard
          title="Avg KYC Achievement"
          value={`${s.avg_kyc_pct?.toFixed(1) || 0}%`}
          subtitle="KYC target completion"
          color="#f0a500"
          icon={Users}
        />
        <KPICard
          title="Avg Collection Eff."
          value={`${s.avg_collection?.toFixed(1) || 0}%`}
          subtitle="Collection efficiency"
          color="#00d4ff"
          icon={Wallet}
        />
        <KPICard
          title="Avg PAR 90"
          value={`${s.avg_par90?.toFixed(2) || 0}%`}
          subtitle="Portfolio at risk"
          color={s.avg_par90 > 5 ? "#ff4444" : "#34d399"}
          icon={Activity}
        />
        <KPICard
          title="Total Branches"
          value={s.total_branches || 0}
          subtitle={`${s.star_count || 0} star · ${s.normal_count || 0} normal`}
          color="#00d4ff"
          icon={Target}
        />
        <KPICard
          title="Critical Branches"
          value={s.critical_count || 0}
          subtitle={`${s.underperform_count || 0} underperforming`}
          color="#ff4444"
          icon={AlertTriangle}
        />
        <KPICard
          title="Star Performers"
          value={s.star_count || 0}
          subtitle="≥100% disbursement"
          color="#00d4ff"
          icon={Star}
        />
        <KPICard
          title="New Customers"
          value={(s.total_new_customers || 0).toLocaleString("en-IN")}
          subtitle="This period"
          color="#34d399"
          icon={Users}
        />
      </div>

      {/* Charts row */}
      <div style={{ display: "grid", gridTemplateColumns: "1fr 320px", gap: 20, marginBottom: 24 }}>

        {/* State bar chart */}
        <div className="glass fade-in" style={{ padding: 20 }}>
          <div style={{ fontFamily: "JetBrains Mono", fontSize: 10, color: "#4a5568", textTransform: "uppercase", letterSpacing: "0.1em", marginBottom: 4 }}>
            State-wise Performance
          </div>
          <h3 className="font-display" style={{ fontSize: 15, fontWeight: 600, color: "#f0f4ff", marginBottom: 16 }}>
            Disbursement Achievement % by State
          </h3>
          {stateChartData.length > 0 ? (
            <ResponsiveContainer width="100%" height={220}>
              <BarChart data={stateChartData} margin={{ top: 0, right: 10, left: -20, bottom: 0 }}>
                <XAxis dataKey="name" tick={{ fill: "#8b95a9", fontSize: 10 }} tickLine={false} axisLine={false} />
                <YAxis tick={{ fill: "#8b95a9", fontSize: 10 }} tickLine={false} axisLine={false} domain={[0, 120]} />
                <Tooltip content={<CustomTooltip />} cursor={{ fill: "rgba(255,255,255,0.03)" }} />
                <Bar dataKey="Achievement" fill="#00d4ff" radius={[4, 4, 0, 0]} maxBarSize={40} name="Achievement %" />
              </BarChart>
            </ResponsiveContainer>
          ) : (
            <div style={{ height: 220, display: "flex", alignItems: "center", justifyContent: "center", color: "#4a5568", fontSize: 13 }}>
              No state data available
            </div>
          )}
        </div>

        {/* Pie chart */}
        <div className="glass fade-in" style={{ padding: 20 }}>
          <div style={{ fontFamily: "JetBrains Mono", fontSize: 10, color: "#4a5568", textTransform: "uppercase", letterSpacing: "0.1em", marginBottom: 4 }}>
            Performance Distribution
          </div>
          <h3 className="font-display" style={{ fontSize: 15, fontWeight: 600, color: "#f0f4ff", marginBottom: 16 }}>
            Branch Status Breakdown
          </h3>
          {pieData.length > 0 ? (
            <ResponsiveContainer width="100%" height={220}>
              <PieChart>
                <Pie
                  data={pieData}
                  cx="50%"
                  cy="45%"
                  innerRadius={55}
                  outerRadius={80}
                  dataKey="value"
                  paddingAngle={2}
                >
                  {pieData.map((entry, i) => (
                    <Cell key={i} fill={entry.color} />
                  ))}
                </Pie>
                <Legend
                  formatter={(value) => <span style={{ color: "#8b95a9", fontSize: 11 }}>{value}</span>}
                />
                <Tooltip content={<CustomTooltip />} />
              </PieChart>
            </ResponsiveContainer>
          ) : (
            <div style={{ height: 220, display: "flex", alignItems: "center", justifyContent: "center", color: "#4a5568" }}>
              No data
            </div>
          )}
        </div>
      </div>

      {/* Flag summary row */}
      <div className="fade-in" style={{ display: "grid", gridTemplateColumns: "repeat(5, 1fr)", gap: 12 }}>
        {Object.entries(FLAG_COLORS).map(([flag, color]) => {
          const count = flagDistribution.find((f) => f.performance_flag === flag)?.count || 0;
          return (
            <button
              key={flag}
              onClick={() => onNavigate("branches")}
              style={{
                padding: "14px 16px",
                borderRadius: 12,
                background: `${color}10`,
                border: `1px solid ${color}25`,
                textAlign: "left",
                cursor: "pointer",
                transition: "all 0.2s",
              }}
              onMouseEnter={(e) => { e.currentTarget.style.border = `1px solid ${color}50`; }}
              onMouseLeave={(e) => { e.currentTarget.style.border = `1px solid ${color}25`; }}
            >
              <div className="font-display" style={{ fontSize: 22, fontWeight: 700, color, marginBottom: 4 }}>
                {count}
              </div>
              <div style={{ fontSize: 11, color: "#8b95a9" }}>
                {FLAG_LABELS[flag]}
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
}
