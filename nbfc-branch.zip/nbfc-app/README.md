# 🏦 NBFC Branch Intelligence System

> A fully local, offline-first desktop application for monitoring NBFC/MFI branch performance — built for security-conscious organisations where data cannot leave the premises.

**Built by [Yug Pratap Gupta](https://www.linkedin.com/in/iamyug/) · AI Automation & Business Systems Engineer**

---

## 🔒 Why This Exists

Most NBFCs and MFIs consolidate branch data manually in Excel every day. Business Heads need performance snapshots, but sharing raw data with cloud tools is a security/compliance risk.

This app solves that: **everything runs on your local machine.** No cloud, no internet, no data leaving your premises. Yet you get a full BI dashboard, automated KPI calculations, and one-click Excel report generation.

---

## ✨ Features

| Feature | Details |
|---|---|
| **100% Local** | SQLite database, all data on your machine |
| **No Setup Complexity** | One installer, no Python/Node install needed |
| **Flexible Column Mapping** | Excel column names change? Update in Settings — no code changes |
| **Auto KPI Calculation** | Disbursement %, KYC %, Collection Efficiency, PAR90, Run Rate, Conversion Ratio |
| **Smart Branch Flagging** | Auto-flags Critical / Underperform / PAR Alert / Star / Normal |
| **Daily & Monthly Targets** | Set daily targets for specific branches needing close monitoring |
| **Excel Report Export** | Colour-coded multi-sheet reports ready to share with Business Heads |
| **State & Region Filters** | Drill down by geography |
| **Multi-Session** | Import multiple periods (monthly, daily, weekly) and compare |
| **Backup & Restore** | One-click database backup |

---

## 📸 Screenshots

> Dashboard, Branch Table, Report Generator, Column Config Settings

---

## 🚀 Installation (For Users)

### Option 1 — Download Installer (Recommended)
1. Go to [Releases](../../releases)
2. Download `NBFC-Branch-Intelligence-Setup-x64.exe`
3. Run the installer — no admin rights needed
4. Launch from Desktop shortcut

**That's it.** No Python, no Node.js, no Excel macros.

### Option 2 — Build from Source
```bash
git clone https://github.com/YOUR_USERNAME/nbfc-branch-intelligence
cd nbfc-branch-intelligence
npm install
npm run dev          # development mode
npm run dist:win     # build Windows installer
```

---

## 📋 How to Use

### 1. Prepare Your Excel File
Your file needs column headers in **row 1**. Example:

| Branch Code | Branch Name | State | Disbursement Target | Disbursement Actual | KYC Target | KYC Actual | PAR 90 | ... |
|---|---|---|---|---|---|---|---|---|

### 2. Import Data
- Click **Import Data** in the sidebar
- Select your `.xlsx` or `.csv` file
- Name the period (e.g. "April 2025" or "12-Apr Daily")
- Choose report type: Monthly / Daily / Weekly
- Click Import — KPIs are calculated automatically

### 3. View Dashboard
Instant overview:
- Total branches, average achievement, PAR alerts
- State-wise bar chart
- Branch status distribution pie chart
- Alert banner for critical branches

### 4. Analyse Branches
Full table with:
- Sortable columns (click any header)
- Quick filter pills (Critical, Star, etc.)
- Search by branch name/code/employee
- State/region/status dropdowns

### 5. Set Daily Targets (Key Feature)
For branches needing close monitoring:
- Go to **Targets** page
- Add a daily target for specific branches or regions
- Useful for: new market entry, underperformers, focus geographies
- Separate from monthly targets — both tracked simultaneously

### 6. Generate Reports
- Go to **Reports** page
- Choose: Full Report / Underperformers / State Summary / Star Performers
- Apply any filters (state, region, status)
- Click Generate — formatted `.xlsx` file saved locally
- Open directly or open the reports folder

---

## ⚙️ Column Customisation

**Your Excel columns changed names? No problem.**

Go to **Settings → Column Mapping** and update the "Excel Column Name" field for any column. That's it — next import will use the new names.

```
System Field          → Your Excel Column (editable)
─────────────────────────────────────────────────────
Branch Code           → "Branch Code"      ← change this if your file says "Br Code"
Disbursement Target   → "Disb Target"      ← or "Monthly Target" or anything
PAR 90                → "PAR90"            ← whatever your file uses
```

---

## 🧮 KPI Calculations

| KPI | Formula |
|---|---|
| Disbursement % | (Actual / Target) × 100 |
| KYC % | (KYC Actual / KYC Target) × 100 |
| Collection Efficiency | (Collection Actual / Collection Target) × 100 |
| PAR90 % | (PAR90 Amount / Portfolio Outstanding) × 100 |
| Run Rate | (Actual / Days Elapsed) × Working Days per Month |
| Conversion Ratio | (Disbursement Cases / KYC Cases) × 100 |

### Branch Flags (Auto-assigned)
| Flag | Condition |
|---|---|
| 🔴 Critical | Disbursement < 40% OR KYC < 40% |
| 🟠 Underperform | Disbursement < 70% OR KYC < 70% |
| ⚠️ PAR Alert | PAR90 > 5% (configurable) |
| ⭐ Star | Disbursement ≥ 100% AND KYC ≥ 90% |
| ✅ Normal | Everything else |

All thresholds are configurable in Settings → KPI Settings.

---

## 🏗️ Tech Stack

| Layer | Technology |
|---|---|
| Desktop Shell | Electron |
| UI | React + Tailwind CSS |
| Database | SQLite (via better-sqlite3) |
| Excel Processing | SheetJS (read) + ExcelJS (write) |
| Charts | Recharts |
| Build/Package | electron-builder |

**Why Electron?** Single installer. No runtime dependencies. Works on any Windows machine. Data stays 100% local — no network calls.

---

## 🗂️ Data Storage

All data stored on your machine:
```
C:\Users\<username>\AppData\Roaming\nbfc-branch-intelligence\
├── nbfc_intelligence.db     ← SQLite database (all your branch data)
├── column_config.json       ← your column name mappings
├── reports\                 ← all generated Excel reports
└── backups\                 ← database backups
```

---

## 🔐 Security

- ✅ No network requests — fully offline
- ✅ No telemetry, no analytics
- ✅ No login or registration
- ✅ Local SQLite — no server, no port, no exposure
- ✅ Data never leaves the machine

---

## 📄 License

MIT — free to use, modify, and deploy within your organisation.

---

## 👤 Author

**Yug Pratap Gupta**  
AI Automation & Business Systems Engineer  
Gurgaon, India  

[LinkedIn](https://www.linkedin.com/in/iamyug/) · [Portfolio](https://yugpratapgupta.vercel.app)

> Built from real operational experience managing 250+ branch performance monitoring at Satin Creditcare Network Limited.
